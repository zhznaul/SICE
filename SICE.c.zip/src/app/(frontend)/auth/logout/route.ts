export async function POST() {
  const secure = process.env.FIGMA === '1' || process.env.NODE_ENV === 'production'
  const base = `app-session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=${secure ? 'None' : 'Lax'}${secure ? '; Secure' : ''}`
  const headers = new Headers({
    'Cache-Control': 'no-store, max-age=0',
    'Clear-Site-Data': '"cache"',
  })
  // Clear both the current CHIPS cookie and sessions created before partitioning was enabled.
  headers.append('Set-Cookie', `${base}${secure ? '; Partitioned' : ''}`)
  if (secure) headers.append('Set-Cookie', base)
  headers.set('Location', '/?logout=1')
  return new Response(null, { status: 303, headers })
}
