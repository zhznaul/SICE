import { appAuth } from '@/lib/app-auth'

export async function POST(request: Request) {
  const contentType = request.headers.get('content-type') || ''
  const nativeForm = contentType.includes('application/x-www-form-urlencoded')

  try {
    const body = nativeForm
      ? Object.fromEntries(await request.formData())
      : ((await request.json()) as {
          email?: unknown
          password?: unknown
          remember?: unknown
        })
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
    const password = typeof body.password === 'string' ? body.password : ''
    const remember = body.remember === true || body.remember === 'on'

    if (!email || !password) {
      if (nativeForm) {
        return new Response(null, {
          status: 303,
          headers: { 'Cache-Control': 'no-store', Location: '/?loginError=1' },
        })
      }
      return Response.json({ ok: false, error: 'Informe e-mail e senha.' }, { status: 400 })
    }

    await appAuth.login(email, password, remember)
    if (nativeForm) {
      return new Response(null, {
        status: 303,
        headers: { 'Cache-Control': 'no-store', Location: '/?login=1' },
      })
    }
    return Response.json({ ok: true }, { headers: { 'Cache-Control': 'no-store, max-age=0' } })
  } catch {
    if (nativeForm) {
      return new Response(null, {
        status: 303,
        headers: { 'Cache-Control': 'no-store', Location: '/?loginError=1' },
      })
    }
    return Response.json({ ok: false, error: 'E-mail ou senha incorretos.' }, { status: 401 })
  }
}
