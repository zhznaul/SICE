'use client'

import { useRouter } from 'next/navigation'

export default function FrontendError({ reset }: { error: Error; reset: () => void }) {
  const router = useRouter()

  return (
    <main className="error-screen">
      <div className="error-card">
        <span>SICE</span>
        <h1>Algo interrompeu esta tela.</h1>
        <p>Você pode tentar novamente ou sair com segurança para renovar a sessão.</p>
        <div>
          <button type="button" onClick={reset}>
            Tentar novamente
          </button>
          <button
            type="button"
            onClick={async () => {
              await fetch('/auth/logout', { method: 'POST' })
              router.refresh()
              reset()
            }}
          >
            Sair da conta
          </button>
        </div>
      </div>
    </main>
  )
}
