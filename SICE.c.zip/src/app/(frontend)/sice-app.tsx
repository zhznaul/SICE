'use client'

import {
  useEffect,
  useRef,
  useState,
  useTransition,
  type CSSProperties,
  type ReactNode,
} from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import QRCode from 'qrcode'
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  Boxes,
  CalendarDays,
  Calculator,
  Check,
  ChevronDown,
  ChevronRight,
  Clock3,
  CircleHelp,
  Download,
  FileText,
  History,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  PackageCheck,
  Paperclip,
  Plus,
  QrCode,
  Search,
  Settings,
  ShoppingCart,
  TrendingUp,
  Upload,
  UserRound,
  UsersRound,
  X,
} from 'lucide-react'
import type { AppUser } from '@/lib/app-auth'
import {
  createEmployeeAction,
  createLabelAction,
  createMovementAction,
  createProductAction,
  createPurchaseOrderAction,
  deleteMovementAction,
  deleteProductAction,
  deletePurchaseOrderAction,
  setProductActiveAction,
  updateEmployeeAction,
  updateEntryAction,
  updateProductAction,
  updatePurchaseOrderAction,
  uploadReceiptAction,
  type ActionResult,
} from './actions'

type Product = {
  id: string | number
  name: string
  category: string
  code: string
  location: string
  quantity: number
  unit: string
  minimumStock: number
  createdAt?: string
  updatedAt?: string
  expiry?: string | null
  purchasedAt?: string | null
  expiryDate?: string | null
  status: 'ok' | 'low' | 'critical'
  unitCost?: number | null
  accent?: string | null
  active?: boolean | null
  catalogType?: 'perishable' | 'non-perishable' | 'beverage' | 'disposable' | null
}

type Movement = {
  id: string | number
  type: 'entry' | 'exit'
  quantity: number
  unit: string
  reason: string
  otherReason?: string | null
  operationalArea?: 'kitchen' | 'bar' | 'storekeeper' | null
  supplier?: string | null
  receivedDate?: string | null
  unitCost?: number | null
  expiryDate?: string | null
  createdAt: string
  product: Product | string | number
  createdBy: TeamMember | string | number
}

type Receipt = {
  id: string | number
  title: string
  supplier?: string | null
  purchaseDate: string
  amount?: number | null
  filename?: string | null
  url?: string | null
}

type TeamMember = {
  id: string | number
  name: string
  email: string
  role: AppUser['role']
  function?: string | null
  active?: boolean | null
}

type PurchaseOrder = {
  id: string | number
  title: string
  product?: Product | string | number | null
  supplier?: string | null
  quantity: number
  unit: string
  unitCost?: number | null
  expectedDate: string
  status: 'planned' | 'ordered' | 'received' | 'cancelled'
  notes?: string | null
}

type Props = {
  user: AppUser | null
  products: Product[]
  movements: Movement[]
  receipts: Receipt[]
  orders: PurchaseOrder[]
  team: TeamMember[]
}

type QrDetection = { rawValue: string }
type QrDetector = {
  detect(source: ImageBitmapSource): Promise<QrDetection[]>
}
type QrDetectorConstructor = new (options: { formats: string[] }) => QrDetector
const inventoryCodeFormats = ['qr_code', 'ean_13', 'ean_8', 'code_128', 'upc_a', 'upc_e']

const roleLabels = {
  owner: 'Proprietário',
  storekeeper: 'Almoxarife',
  operational: 'Equipe operacional',
}

const areaLabels = {
  kitchen: 'Cozinha',
  bar: 'Bar',
  storekeeper: 'Almoxarife',
}

const catalogTypeLabels = {
  perishable: 'Perecível',
  'non-perishable': 'Não perecível',
  beverage: 'Bebida',
  disposable: 'Descartável',
}

const money = (value: number) =>
  new Intl.NumberFormat('pt-BR', { currency: 'BRL', style: 'currency' }).format(value)

const formatDate = (value?: string | null) =>
  value ? new Date(value).toLocaleDateString('pt-BR', { timeZone: 'UTC' }) : 'Não informado'

const expiresSoon = (product: Product) => {
  if (product.expiryDate) {
    const days = (new Date(product.expiryDate).getTime() - Date.now()) / 86_400_000
    return days <= 7
  }
  return /hoje|amanhã|^[0-7]\s*dias?/i.test(product.expiry || '')
}

const needsAttention = (product: Product) =>
  product.quantity <= product.minimumStock || product.status === 'critical' || expiresSoon(product)

const inventoryGroups = [
  'Hortifrúti',
  'Carnes e pescados',
  'Laticínios e frios',
  'Bebidas',
  'Materiais descartáveis',
] as const

type InventoryGroup = (typeof inventoryGroups)[number]

const inventoryGroup = (product: Product): InventoryGroup => {
  const reference = `${product.name} ${product.category}`.toLowerCase()
  if (/bebida|gin|vinho|cerveja|whisky|vodka|rum|suco|água|refrigerante/.test(reference)) {
    return 'Bebidas'
  }
  if (/descart|guardanapo|canudo|embalagem|sacola|copo|luva|papel/.test(reference)) {
    return 'Materiais descartáveis'
  }
  if (/latic|queijo|leite|creme|manteiga|iogurte|frios/.test(reference)) {
    return 'Laticínios e frios'
  }
  if (/proteína|frutos do mar|carne|filé|salmão|camarão|polvo|lula|robalo|peixe/.test(reference)) {
    return 'Carnes e pescados'
  }
  return 'Hortifrúti'
}

const priorityScore = (product: Product) =>
  (product.status === 'critical' ? 4 : 0) +
  (expiresSoon(product) ? 3 : 0) +
  (product.quantity <= product.minimumStock ? 2 : 0) +
  (product.status === 'low' ? 1 : 0)

function Logo({ dark = false, compact = false }: { dark?: boolean; compact?: boolean }) {
  return (
    <div className={`brand ${dark ? 'brand--dark' : ''} ${compact ? 'brand--compact' : ''}`}>
      <div className="brand-mark brand-mark--single" aria-label="SICE">
        <b>S</b>
      </div>
      {!compact && (
        <div>
          <strong>SICE</strong>
          <small>sistema inteligente de estoque</small>
        </div>
      )}
    </div>
  )
}

function LoginScreen() {
  const [error, setError] = useState('')
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('loginError') === '1') {
      setError('E-mail ou senha incorretos.')
    }
  }, [])

  return (
    <div className="login-screen">
      <section className="login-story">
        <Logo />
        <div className="login-copy">
          <span className="login-overline">GESTÃO QUE ALIMENTA DECISÕES</span>
          <h1>Seu estoque, objetivo como deve ser.</h1>
          <p>Controle insumos, reduza perdas e acompanhe o CMV da sua operação em tempo real.</p>
          <div className="login-proof">
            <strong>−18%</strong>
            <span>de desperdício médio nas operações acompanhadas</span>
          </div>
        </div>
        <small>© 2026 SICE · Controle inteligente para hospitalidade</small>
      </section>
      <section className="login-form-wrap">
        <div className="login-form-card">
          <Logo dark />
          <div className="login-heading">
            <span>ACESSO RESTRITO</span>
            <h2>Identifique-se para começar</h2>
            <p>Use o login e a senha fornecidos pela gerência.</p>
          </div>
          <form action="/auth/session" method="post">
            <label className="login-field">
              <span>E-mail</span>
              <div>
                <Mail size={17} />
                <input name="email" type="email" placeholder="seu.nome@empresa.com.br" required />
              </div>
            </label>
            <label className="login-field">
              <span>Senha</span>
              <div>
                <KeyRound size={17} />
                <input name="password" type="password" placeholder="Digite sua senha" required />
              </div>
            </label>
            <div className="login-options">
              <label>
                <input name="remember" type="checkbox" defaultChecked /> Manter conectado
              </label>
            </div>
            {error && <p className="form-error">{error}</p>}
            <button className="btn btn--primary login-submit" type="submit">
              Entrar no SICE <ArrowRight size={18} />
            </button>
          </form>
          <p className="login-support">Credenciais individuais e protegidas por perfil.</p>
        </div>
      </section>
    </div>
  )
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="empty-state">
      <Boxes size={22} />
      <strong>{text}</strong>
      <span>Os registros persistentes aparecerão aqui.</span>
    </div>
  )
}

function ActionForm({
  action,
  children,
  onDone,
  className,
}: {
  action: (form: FormData) => Promise<ActionResult>
  children: ReactNode
  onDone: (result: ActionResult) => void
  className?: string
}) {
  const [pending, startTransition] = useTransition()
  return (
    <form
      className={className}
      onSubmit={(event) => {
        event.preventDefault()
        const element = event.currentTarget
        const form = new FormData(element)
        startTransition(async () => {
          const result = await action(form)
          if (result.ok) element.reset()
          onDone(result)
        })
      }}
    >
      {children}
      <button className="btn btn--primary" disabled={pending} type="submit">
        {pending ? 'Salvando...' : 'Salvar'} <ArrowRight size={16} />
      </button>
    </form>
  )
}

function ConfirmAction({
  action,
  id,
  label,
  question,
  onDone,
}: {
  action: (form: FormData) => Promise<ActionResult>
  id: string | number
  label: string
  question: string
  onDone: (result: ActionResult) => void
}) {
  const [pending, startTransition] = useTransition()
  return (
    <button
      className="danger-action"
      type="button"
      disabled={pending}
      onClick={() => {
        if (!window.confirm(question)) return
        const form = new FormData()
        form.set('id', String(id))
        startTransition(async () => onDone(await action(form)))
      }}
    >
      {pending ? 'Aguarde...' : label}
    </button>
  )
}

function LogoutButton({ className, iconOnly = false }: { className: string; iconOnly?: boolean }) {
  return (
    <form className="logout-form" action="/auth/logout" method="post">
      <button className={className} type="submit" aria-label="Sair da conta" title="Sair da conta">
        <LogOut size={iconOnly ? 18 : 17} />
        {!iconOnly && ' Sair da conta'}
      </button>
    </form>
  )
}

function ProductAvailabilityAction({
  product,
  onDone,
  close,
}: {
  product: Product
  onDone: (result: ActionResult) => void
  close: () => void
}) {
  const [pending, startTransition] = useTransition()
  const nextActive = product.active === false
  return (
    <button
      className="danger-action"
      type="button"
      disabled={pending}
      onClick={() => {
        if (
          !window.confirm(
            nextActive
              ? 'Reativar este insumo no catálogo?'
              : 'Inativar este insumo sem apagar seu histórico?',
          )
        )
          return
        const form = new FormData()
        form.set('id', String(product.id))
        form.set('active', String(nextActive))
        startTransition(async () => {
          const result = await setProductActiveAction(form)
          onDone(result)
          if (result.ok) close()
        })
      }}
    >
      {pending ? 'Aguarde...' : nextActive ? 'Reativar insumo' : 'Inativar insumo'}
    </button>
  )
}

export function SiceApp(props: Props) {
  if (!props.user) return <LoginScreen />
  return <Dashboard {...props} user={props.user} />
}

function Dashboard({
  user,
  products,
  movements,
  receipts,
  orders,
  team,
}: Props & { user: AppUser }) {
  const router = useRouter()
  const [active, setActive] = useState('Visão geral')
  const [screenHistory, setScreenHistory] = useState<string[]>([])
  const [query, setQuery] = useState('')
  const [mobile, setMobile] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [movementProduct, setMovementProduct] = useState('')
  const [modal, setModal] = useState<'product' | 'entry' | 'exit' | null>(null)
  const [toast, setToast] = useState('')
  const canManageInventory = user.role !== 'operational'
  const canPurchase = user.role !== 'operational'
  const isOwner = user.role === 'owner'
  const initials = user.name
    .split(' ')
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase()

  const navigate = (screen: string) => {
    if (screen === active) return
    setScreenHistory((history) => [...history, active].slice(-12))
    setActive(screen)
  }

  const goBack = () => {
    const previous = screenHistory.at(-1) || 'Visão geral'
    setScreenHistory((history) => history.slice(0, -1))
    setActive(previous)
  }

  const notify = (result: ActionResult) => {
    setToast(result.ok ? result.message : result.error)
    if (result.ok) {
      setModal(null)
      setMovementProduct('')
      router.refresh()
    }
    window.setTimeout(() => setToast(''), 3600)
  }

  const nav = [
    { label: 'Visão geral', icon: LayoutDashboard, show: true },
    { label: 'Estoque', icon: Boxes, show: true },
    { label: 'Movimentações', icon: History, show: true },
    { label: 'Alertas', icon: Bell, show: true },
    { label: 'Compras', icon: ShoppingCart, show: canPurchase },
    { label: 'Relatórios', icon: BarChart3, show: canPurchase },
    { label: 'Equipe', icon: UsersRound, show: isOwner },
    { label: 'Etiquetas', icon: QrCode, show: true },
    { label: 'Ler QR Code', icon: QrCode, show: true },
  ]

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobile ? 'sidebar--open' : ''}`}>
        <div className="sidebar-top">
          <Logo />
          <button
            className="mobile-close icon-btn"
            onClick={() => setMobile(false)}
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>
        <div className="restaurant-card">
          <Image
            src="/allto-view.png"
            alt="Vista para o mar do restaurante Allto Al Mar"
            width={42}
            height={42}
          />
          <div>
            <span>Unidade ativa</span>
            <strong>Allto Al Mar</strong>
            <small>Rooftop · Santos, SP</small>
          </div>
        </div>
        <nav className="main-nav">
          <span className="nav-label">OPERAÇÃO</span>
          {nav
            .filter((item) => item.show)
            .map(({ label, icon: Icon }) => (
              <button
                className={active === label ? 'active' : ''}
                key={label}
                onClick={() => {
                  navigate(label)
                  setMobile(false)
                }}
              >
                <Icon size={19} />
                <span>{label}</span>
              </button>
            ))}
          <span className="nav-label nav-label--second">SISTEMA</span>
          <button onClick={() => navigate('Login e senha')}>
            <Settings size={19} />
            <span>Login e senha</span>
          </button>
          <button onClick={() => setToast('Central de ajuda aberta')}>
            <CircleHelp size={19} />
            <span>Ajuda e suporte</span>
          </button>
        </nav>
        <div className="user-card">
          <div className="avatar">{initials}</div>
          <button className="user-card-main" onClick={() => setProfileOpen(!profileOpen)}>
            <strong>{user.name}</strong>
            <span>{roleLabels[user.role]}</span>
          </button>
          <button onClick={() => setProfileOpen(!profileOpen)} aria-label="Abrir perfil">
            <ChevronDown size={17} />
          </button>
          {profileOpen && (
            <div className="account-menu account-menu--profile">
              <span>MINHA CONTA</span>
              <div className="profile-summary">
                <i>{initials}</i>
                <div>
                  <strong>{user.name}</strong>
                  <small>{user.email}</small>
                </div>
              </div>
              <LogoutButton className="account-logout" />
            </div>
          )}
        </div>
      </aside>

      {mobile && <button className="menu-backdrop" onClick={() => setMobile(false)} />}

      <main>
        <header className="topbar">
          <div className="mobile-brand">
            <button className="icon-btn" onClick={() => setMobile(true)} aria-label="Abrir menu">
              <Menu size={22} />
            </button>
            <Logo compact />
          </div>
          <div className="global-search">
            <Search size={19} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar insumo ou código..."
            />
          </div>
          <div className="top-actions">
            <span className="date-chip">{roleLabels[user.role]}</span>
            <button
              className="notification-btn"
              aria-label="Abrir alertas"
              onClick={() => navigate('Alertas')}
            >
              <Bell size={20} />
              <i>{products.filter(needsAttention).length}</i>
            </button>
            <LogoutButton className="topbar-logout" iconOnly />
          </div>
        </header>

        <div className="page">
          {active !== 'Visão geral' && (
            <button className="screen-back" type="button" onClick={goBack}>
              <ArrowLeft size={17} /> Voltar
            </button>
          )}
          {active === 'Visão geral' && (
            <Overview
              user={user}
              products={products}
              movements={movements}
              canManageInventory={canManageInventory}
              openModal={setModal}
              goTo={navigate}
              onSelect={setSelectedProduct}
            />
          )}
          {active === 'Estoque' && (
            <Inventory
              products={products}
              query={query}
              canManageInventory={canManageInventory}
              openAdd={() => setModal('product')}
              onSelect={setSelectedProduct}
            />
          )}
          {active === 'Movimentações' && (
            <Movements
              movements={movements}
              openModal={setModal}
              canManage={canManageInventory}
              onDone={notify}
            />
          )}
          {active === 'Alertas' && (
            <Alerts products={products} movements={movements} onSelect={setSelectedProduct} />
          )}
          {active === 'Compras' && canPurchase && (
            <Purchases products={products} receipts={receipts} orders={orders} onDone={notify} />
          )}
          {active === 'Relatórios' && canPurchase && (
            <Reports
              products={products}
              movements={movements}
              receipts={receipts}
              isOwner={isOwner}
            />
          )}
          {active === 'Equipe' && isOwner && <Team team={team} onDone={notify} />}
          {active === 'Etiquetas' && <Labels products={products} onDone={notify} />}
          {active === 'Ler QR Code' && (
            <QrScanner
              products={products}
              onDetected={(product) => {
                if (canManageInventory) {
                  setSelectedProduct(product)
                } else {
                  setMovementProduct(String(product.id))
                  setModal('exit')
                }
              }}
              managementMode={canManageInventory}
            />
          )}
          {active === 'Login e senha' && <Account user={user} />}
        </div>
      </main>

      <nav className="mobile-bottom-nav" aria-label="Navegação rápida">
        {[
          ['Visão geral', LayoutDashboard],
          ['Estoque', Boxes],
          ['Ler QR Code', QrCode],
          ['Movimentações', History],
          ['Login e senha', UserRound],
        ].map(([label, Icon], index) => (
          <button
            className={`${active === label ? 'active' : ''} ${index === 2 ? 'scan' : ''}`}
            key={label as string}
            onClick={() => navigate(label as string)}
          >
            <Icon size={index === 2 ? 22 : 19} />
            <span>
              {label === 'Visão geral'
                ? 'Início'
                : label === 'Movimentações'
                  ? 'Histórico'
                  : label === 'Login e senha'
                    ? 'Perfil'
                    : (label as string)}
            </span>
          </button>
        ))}
      </nav>

      {modal && (
        <MovementModal
          kind={modal}
          products={products}
          user={user}
          initialProductId={movementProduct}
          close={() => {
            setModal(null)
            setMovementProduct('')
          }}
          onDone={notify}
        />
      )}
      {selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          movements={movements}
          canViewMoney={canManageInventory}
          canManage={canManageInventory}
          onDone={notify}
          close={() => setSelectedProduct(null)}
          openMovement={(kind) => {
            setMovementProduct(String(selectedProduct.id))
            setSelectedProduct(null)
            setModal(kind)
          }}
        />
      )}
      {toast && (
        <div className="toast">
          <span>
            <Check size={15} />
          </span>
          {toast}
        </div>
      )}
    </div>
  )
}

function PageTitle({
  kicker,
  title,
  text,
  action,
}: {
  kicker: string
  title: string
  text: string
  action?: ReactNode
}) {
  return (
    <section className="page-title">
      <div>
        <div className="eyebrow">
          <span /> {kicker}
        </div>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
      {action}
    </section>
  )
}

function Overview({
  user,
  products,
  movements,
  canManageInventory,
  openModal,
  goTo,
  onSelect,
}: {
  user: AppUser
  products: Product[]
  movements: Movement[]
  canManageInventory: boolean
  openModal: (modal: 'product' | 'entry' | 'exit') => void
  goTo: (page: string) => void
  onSelect: (product: Product) => void
}) {
  const low = products.filter(needsAttention)
  return (
    <>
      <section className="welcome">
        <div>
          <div className="eyebrow">
            <span /> OPERAÇÃO DE HOJE
          </div>
          <h1>Bom dia, {user.name.split(' ')[0]}.</h1>
          <p>
            Seu estoque exige atenção em <strong>{low.length} itens</strong>. Vamos organizar as
            prioridades?
          </p>
        </div>
        <div className="welcome-actions">
          <button className="btn btn--light" onClick={() => openModal('entry')}>
            <ArrowDownLeft size={18} /> Nova entrada
          </button>
          <button className="btn btn--primary" onClick={() => openModal('exit')}>
            <ArrowUpRight size={18} /> Registrar baixa
          </button>
        </div>
      </section>
      <section className="metrics-grid">
        {canManageInventory && (
          <article className="metric-card metric-card--dark">
            <Boxes size={22} />
            <span>Valor em estoque</span>
            <strong>
              {money(
                products.reduce(
                  (sum, product) => sum + product.quantity * (product.unitCost || 0),
                  0,
                ),
              )}
            </strong>
            <small>Atualizado pelos insumos cadastrados</small>
          </article>
        )}
        <article className="metric-card">
          <div className="metric-icon metric-icon--green">
            <PackageCheck size={21} />
          </div>
          <span>Total de insumos</span>
          <strong>{products.length}</strong>
          <small>cadastros ativos</small>
        </article>
        <article className="metric-card">
          <div className="metric-icon metric-icon--amber">
            <AlertTriangle size={21} />
          </div>
          <span>Estoque mínimo</span>
          <strong>
            {low.length} <em>itens</em>
          </strong>
          <small>precisam de atenção</small>
        </article>
        <article className="metric-card">
          <div className="metric-icon metric-icon--red">
            <History size={21} />
          </div>
          <span>Movimentações</span>
          <strong>{movements.length}</strong>
          <small>registros recentes</small>
        </article>
      </section>
      <section className="panel attention-panel">
        <div className="section-heading">
          <div>
            <span className="section-kicker">PRIORIDADE OPERACIONAL</span>
            <h2>Itens que exigem atenção</h2>
          </div>
          <button onClick={() => goTo('Estoque')}>
            Ver estoque <ArrowRight size={16} />
          </button>
        </div>
        <ProductRows products={low.length ? low : products.slice(0, 5)} onSelect={onSelect} />
      </section>
    </>
  )
}

function ProductRows({
  products,
  onSelect,
}: {
  products: Product[]
  onSelect?: (product: Product) => void
}) {
  if (!products.length) return <EmptyState text="Nenhum insumo cadastrado" />
  return (
    <div className="product-list">
      {products.map((product) => (
        <button
          className="product-row"
          key={product.id}
          onClick={() => onSelect?.(product)}
          type="button"
        >
          <span
            className="product-art"
            style={{ '--accent': product.accent || '#376759' } as CSSProperties}
          >
            <Boxes size={19} />
          </span>
          <span className="product-main">
            <strong>{product.name}</strong>
            <small>
              {product.code} · {inventoryGroup(product)} · {product.location}
            </small>
          </span>
          <span className="product-stock">
            <small>DISPONÍVEL</small>
            <strong>
              {product.quantity} <em>{product.unit}</em>
            </strong>
          </span>
          <span className="product-expiry">
            <small>VALIDADE</small>
            <strong>
              {product.expiryDate ? formatDate(product.expiryDate) : product.expiry || '—'}
            </strong>
          </span>
          <span className={`status status--${product.status}`}>
            <i />
            {product.active === false
              ? 'Inativo'
              : product.status === 'ok'
                ? 'Saudável'
                : product.status === 'low'
                  ? 'Estoque baixo'
                  : 'Prioridade PVPS'}
          </span>
          <ChevronRight className="row-arrow" size={18} />
        </button>
      ))}
    </div>
  )
}

function Inventory({
  products,
  query,
  canManageInventory,
  openAdd,
  onSelect,
}: {
  products: Product[]
  query: string
  canManageInventory: boolean
  openAdd: () => void
  onSelect: (product: Product) => void
}) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState<InventoryGroup | 'Todos'>('Todos')
  const [order, setOrder] = useState<'priority' | 'name' | 'stock'>('priority')
  const term = `${query} ${search}`.trim().toLowerCase()
  const visible = products
    .filter(
      (product) =>
        (category === 'Todos' || inventoryGroup(product) === category) &&
        `${product.name} ${product.code} ${product.location} ${inventoryGroup(product)}`
          .toLowerCase()
          .includes(term),
    )
    .sort((a, b) => {
      if (order === 'name') return a.name.localeCompare(b.name, 'pt-BR')
      if (order === 'stock') return a.quantity - b.quantity
      return priorityScore(b) - priorityScore(a) || a.name.localeCompare(b.name, 'pt-BR')
    })
  return (
    <>
      <PageTitle
        kicker="CONTROLE DE INSUMOS"
        title="Estoque"
        text={
          canManageInventory
            ? 'Cadastre e edite livremente os nomes dos insumos.'
            : 'Selecione entre os insumos oferecidos pela gestão.'
        }
        action={
          canManageInventory ? (
            <button className="btn btn--primary" onClick={openAdd}>
              <Plus size={18} /> Novo insumo
            </button>
          ) : undefined
        }
      />
      <section
        className="category-overview inventory-categories"
        aria-label="Categorias do estoque"
      >
        {inventoryGroups.map((group, index) => {
          const count = products.filter((product) => inventoryGroup(product) === group).length
          return (
            <button
              className={category === group ? 'active' : ''}
              type="button"
              key={group}
              onClick={() => setCategory(category === group ? 'Todos' : group)}
            >
              <i className={`category-accent category-accent--${index + 1}`} />
              <span>CATEGORIA</span>
              <strong>{group}</strong>
              <small>{count} insumos</small>
            </button>
          )
        })}
      </section>
      <section className="panel inventory-panel">
        <div className="inventory-toolbar">
          <label className="inventory-search">
            <Search size={17} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Pesquisar por nome, código, local ou categoria"
            />
          </label>
          <div className="inventory-controls">
            <button
              type="button"
              className={category === 'Todos' ? 'active' : ''}
              onClick={() => setCategory('Todos')}
            >
              Todos ({products.length})
            </button>
            <select
              value={order}
              onChange={(event) => setOrder(event.target.value as typeof order)}
            >
              <option value="priority">Prioridade</option>
              <option value="name">Nome A–Z</option>
              <option value="stock">Menor estoque</option>
            </select>
          </div>
        </div>
        <ProductRows products={visible} onSelect={onSelect} />
      </section>
    </>
  )
}

function Movements({
  movements,
  openModal,
  canManage,
  onDone,
}: {
  movements: Movement[]
  openModal: (value: 'entry' | 'exit') => void
  canManage: boolean
  onDone: (result: ActionResult) => void
}) {
  return (
    <>
      <PageTitle
        kicker="RASTREABILIDADE"
        title="Movimentações"
        text="Histórico completo de entradas e baixas registradas."
        action={
          <div className="movement-page-actions">
            <button className="btn btn--light" onClick={() => openModal('exit')}>
              <ArrowUpRight size={18} /> Registrar baixa
            </button>
            {canManage && (
              <button className="btn btn--primary" onClick={() => openModal('entry')}>
                <ArrowDownLeft size={18} /> Nova entrada
              </button>
            )}
          </div>
        }
      />
      <section className="panel movement-history">
        {movements.length ? (
          movements.map((movement) => {
            const product = typeof movement.product === 'object' ? movement.product : null
            const responsible =
              typeof movement.createdBy === 'object' ? movement.createdBy.name : 'Responsável'
            return (
              <div className="movement-history-row" key={movement.id}>
                <span className="movement-history-product">
                  <i className={movement.type}>
                    <Boxes size={17} />
                  </i>
                  <span>
                    <strong>{product?.name || 'Insumo'}</strong>
                    <small>{product?.code || 'Registro preservado'}</small>
                  </span>
                </span>
                <span className={`movement-kind ${movement.type}`}>
                  <span>
                    <strong>{movement.type === 'entry' ? 'Entrada' : 'Baixa'}</strong>
                    <small>
                      {movement.reason}
                      {movement.otherReason ? ` · ${movement.otherReason}` : ''}
                    </small>
                  </span>
                </span>
                <span className="movement-responsible">
                  <strong>{responsible}</strong>
                  <small>
                    {movement.operationalArea
                      ? areaLabels[movement.operationalArea]
                      : 'Registro identificado'}
                  </small>
                </span>
                <strong className={movement.type}>
                  {movement.type === 'entry' ? '+' : '−'}
                  {movement.quantity} {movement.unit}
                </strong>
                <span>{new Date(movement.createdAt).toLocaleDateString('pt-BR')}</span>
                {canManage && movement.type === 'entry' && (
                  <details className="record-editor">
                    <summary>Editar entrada</summary>
                    <ActionForm action={updateEntryAction} onDone={onDone}>
                      <input type="hidden" name="id" value={movement.id} />
                      <div className="form-grid">
                        <label className="form-field">
                          <span>Quantidade</span>
                          <input
                            name="quantity"
                            type="number"
                            min="0.01"
                            step="0.01"
                            defaultValue={movement.quantity}
                            required
                          />
                        </label>
                        <label className="form-field">
                          <span>Unidade</span>
                          <select name="unit" defaultValue={movement.unit}>
                            {['kg', 'g', 'un', 'litros', 'caixa'].map((unit) => (
                              <option key={unit}>{unit}</option>
                            ))}
                          </select>
                        </label>
                        <label className="form-field">
                          <span>Fornecedor</span>
                          <input name="supplier" defaultValue={movement.supplier || ''} />
                        </label>
                        <label className="form-field">
                          <span>Recebido em</span>
                          <input
                            name="receivedDate"
                            type="date"
                            defaultValue={movement.receivedDate?.slice(0, 10) || ''}
                          />
                        </label>
                        <label className="form-field">
                          <span>Custo unitário</span>
                          <input
                            name="unitCost"
                            type="number"
                            min="0"
                            step="0.01"
                            defaultValue={movement.unitCost || ''}
                          />
                        </label>
                        <label className="form-field">
                          <span>Validade</span>
                          <input
                            name="expiryDate"
                            type="date"
                            defaultValue={movement.expiryDate?.slice(0, 10) || ''}
                          />
                        </label>
                      </div>
                    </ActionForm>
                    <ConfirmAction
                      action={deleteMovementAction}
                      id={movement.id}
                      label="Remover entrada"
                      question="Remover esta entrada e recalcular o saldo?"
                      onDone={onDone}
                    />
                  </details>
                )}
              </div>
            )
          })
        ) : (
          <EmptyState text="Nenhuma movimentação registrada" />
        )}
      </section>
    </>
  )
}

function Purchases({
  products,
  receipts,
  orders,
  onDone,
}: {
  products: Product[]
  receipts: Receipt[]
  orders: PurchaseOrder[]
  onDone: (result: ActionResult) => void
}) {
  return (
    <>
      <PageTitle
        kicker="COMPRAS E DOCUMENTOS"
        title="Compras"
        text="Consulte o histórico, guarde comprovantes e planeje compras futuras."
      />
      <section className="panel purchase-planner">
        <div className="section-heading compact">
          <div>
            <span className="section-kicker">PRÓXIMAS COMPRAS</span>
            <h2>Planejamento de reposição</h2>
          </div>
          <span className="count-badge">{orders.length}</span>
        </div>
        <ActionForm action={createPurchaseOrderAction} onDone={onDone}>
          <div className="form-grid">
            <label className="form-field">
              <span>Item da compra</span>
              <input name="title" required placeholder="Ex.: Pescados da semana" />
            </label>
            <label className="form-field">
              <span>Insumo relacionado</span>
              <select name="product" defaultValue="">
                <option value="">Compra geral</option>
                {products
                  .filter((product) => product.active !== false)
                  .map((product) => (
                    <option value={product.id} key={product.id}>
                      {product.name}
                    </option>
                  ))}
              </select>
            </label>
            <label className="form-field">
              <span>Fornecedor</span>
              <input name="supplier" />
            </label>
            <label className="form-field">
              <span>Data prevista</span>
              <input name="expectedDate" type="date" required />
            </label>
            <label className="form-field">
              <span>Quantidade</span>
              <input name="quantity" type="number" min="0.01" step="0.01" required />
            </label>
            <label className="form-field">
              <span>Unidade</span>
              <select name="unit">
                {['kg', 'g', 'un', 'litros', 'caixa'].map((unit) => (
                  <option key={unit}>{unit}</option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Custo unitário previsto</span>
              <input name="unitCost" type="number" min="0" step="0.01" />
            </label>
            <label className="form-field">
              <span>Observações</span>
              <input name="notes" />
            </label>
          </div>
        </ActionForm>
        <div className="purchase-order-list">
          {orders.length ? (
            orders.map((order) => {
              const orderProductID =
                order.product && typeof order.product === 'object'
                  ? order.product.id
                  : order.product || ''
              return (
                <article key={order.id}>
                  <div>
                    <strong>{order.title}</strong>
                    <small>
                      {order.quantity} {order.unit} · {order.supplier || 'Fornecedor a definir'} ·{' '}
                      {formatDate(order.expectedDate)}
                    </small>
                  </div>
                  <span className={`order-status order-status--${order.status}`}>
                    {
                      {
                        planned: 'Planejada',
                        ordered: 'Solicitada',
                        received: 'Recebida',
                        cancelled: 'Cancelada',
                      }[order.status]
                    }
                  </span>
                  <details className="record-editor purchase-order-editor">
                    <summary>Editar pedido</summary>
                    <ActionForm action={updatePurchaseOrderAction} onDone={onDone}>
                      <input type="hidden" name="id" value={order.id} />
                      <div className="form-grid">
                        <label className="form-field">
                          <span>Item</span>
                          <input name="title" defaultValue={order.title} required />
                        </label>
                        <label className="form-field">
                          <span>Insumo</span>
                          <select name="product" defaultValue={String(orderProductID)}>
                            <option value="">Compra geral</option>
                            {products.map((product) => (
                              <option value={product.id} key={product.id}>
                                {product.name}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label className="form-field">
                          <span>Fornecedor</span>
                          <input name="supplier" defaultValue={order.supplier || ''} />
                        </label>
                        <label className="form-field">
                          <span>Data prevista</span>
                          <input
                            name="expectedDate"
                            type="date"
                            defaultValue={order.expectedDate.slice(0, 10)}
                            required
                          />
                        </label>
                        <label className="form-field">
                          <span>Quantidade</span>
                          <input
                            name="quantity"
                            type="number"
                            min="0.01"
                            step="0.01"
                            defaultValue={order.quantity}
                            required
                          />
                        </label>
                        <label className="form-field">
                          <span>Unidade</span>
                          <select name="unit" defaultValue={order.unit}>
                            {['kg', 'g', 'un', 'litros', 'caixa'].map((unit) => (
                              <option key={unit}>{unit}</option>
                            ))}
                          </select>
                        </label>
                        <label className="form-field">
                          <span>Custo unitário</span>
                          <input
                            name="unitCost"
                            type="number"
                            min="0"
                            step="0.01"
                            defaultValue={order.unitCost || ''}
                          />
                        </label>
                        <label className="form-field">
                          <span>Status</span>
                          <select name="status" defaultValue={order.status}>
                            <option value="planned">Planejada</option>
                            <option value="ordered">Solicitada</option>
                            <option value="received">Recebida</option>
                            <option value="cancelled">Cancelada</option>
                          </select>
                        </label>
                        <label className="form-field full-width">
                          <span>Observações</span>
                          <input name="notes" defaultValue={order.notes || ''} />
                        </label>
                      </div>
                    </ActionForm>
                  </details>
                  <ConfirmAction
                    action={deletePurchaseOrderAction}
                    id={order.id}
                    label="Remover"
                    question="Remover esta compra planejada?"
                    onDone={onDone}
                  />
                </article>
              )
            })
          ) : (
            <EmptyState text="Nenhuma compra futura planejada" />
          )}
        </div>
      </section>
      <section className="purchase-layout">
        <article className="panel upload-card">
          <div className="settings-card-head">
            <span>
              <Upload size={20} />
            </span>
            <div>
              <h2>Novo comprovante</h2>
              <p>Use a câmera do celular ou escolha um PDF/imagem.</p>
            </div>
          </div>
          <ActionForm action={uploadReceiptAction} onDone={onDone}>
            <div className="form-grid">
              <label className="form-field">
                <span>Título</span>
                <input name="title" required placeholder="Ex.: Nota fiscal hortifruti" />
              </label>
              <label className="form-field">
                <span>Fornecedor</span>
                <input name="supplier" placeholder="Nome do fornecedor" />
              </label>
              <label className="form-field">
                <span>Data da compra</span>
                <input name="purchaseDate" type="date" required />
              </label>
              <label className="form-field">
                <span>Valor</span>
                <input name="amount" type="number" min="0" step="0.01" placeholder="0,00" />
              </label>
            </div>
            <label className="receipt-drop">
              <Paperclip size={24} />
              <strong>Escanear ou fazer upload</strong>
              <span>PDF, JPG, PNG ou WEBP · até 10 MB</span>
              <input
                name="file"
                type="file"
                accept="application/pdf,image/*"
                capture="environment"
                required
              />
            </label>
          </ActionForm>
        </article>
        <article className="panel receipt-folder">
          <div className="section-heading compact">
            <div>
              <span className="section-kicker">PASTA DE COMPROVANTES</span>
              <h2>Arquivos guardados</h2>
            </div>
            <span className="count-badge">{receipts.length}</span>
          </div>
          {receipts.length ? (
            receipts.map((receipt) => (
              <a
                className="receipt-row"
                href={receipt.url || '#'}
                target="_blank"
                rel="noreferrer"
                key={receipt.id}
              >
                <span>
                  <FileText size={18} />
                </span>
                <div>
                  <strong>{receipt.title}</strong>
                  <small>
                    {receipt.supplier || 'Sem fornecedor'} ·{' '}
                    {new Date(receipt.purchaseDate).toLocaleDateString('pt-BR')}
                  </small>
                </div>
                <b>{receipt.amount ? money(receipt.amount) : 'Abrir'}</b>
              </a>
            ))
          ) : (
            <EmptyState text="A pasta ainda está vazia" />
          )}
        </article>
      </section>
    </>
  )
}

function Reports({
  products,
  movements,
  receipts,
  isOwner,
}: {
  products: Product[]
  movements: Movement[]
  receipts: Receipt[]
  isOwner: boolean
}) {
  const exits = movements.filter((movement) => movement.type === 'exit')
  const chart = [54, 72, 61, 84, 68, 91, 77, 88]
  const stockValue = products.reduce(
    (sum, product) => sum + product.quantity * (product.unitCost || 0),
    0,
  )
  const currentMonth = new Date()
  const isCurrentMonth = (value: string) => {
    const date = new Date(value)
    return (
      date.getMonth() === currentMonth.getMonth() &&
      date.getFullYear() === currentMonth.getFullYear()
    )
  }
  const monthlyMovements = movements.filter((movement) =>
    isCurrentMonth(movement.receivedDate || movement.createdAt),
  )
  const movementValue = (movement: Movement) => {
    const product = typeof movement.product === 'object' ? movement.product : null
    return movement.quantity * (movement.unitCost || product?.unitCost || 0)
  }
  const monthlyEntriesValue = monthlyMovements
    .filter((movement) => movement.type === 'entry')
    .reduce((sum, movement) => sum + movementValue(movement), 0)
  const monthlyExitsValue = monthlyMovements
    .filter((movement) => movement.type === 'exit')
    .reduce((sum, movement) => sum + movementValue(movement), 0)
  const monthlyReceiptTotal = receipts
    .filter((receipt) => isCurrentMonth(receipt.purchaseDate))
    .reduce((sum, receipt) => sum + (receipt.amount || 0), 0)
  const lossMovements = exits.filter((movement) =>
    /descarte|avaria|validade|outros/i.test(movement.reason),
  )
  const lossCost = lossMovements.reduce((sum, movement) => {
    const product = typeof movement.product === 'object' ? movement.product : null
    return sum + movement.quantity * (product?.unitCost || 0)
  }, 0)
  const averageWaste = lossMovements.length ? lossCost / lossMovements.length : 0
  const calculatedPurchases = monthlyEntriesValue || monthlyReceiptTotal
  const calculatedOpeningStock = Math.max(0, stockValue - monthlyEntriesValue + monthlyExitsValue)
  const suggestedRevenue = Math.max(
    45000,
    (calculatedOpeningStock + calculatedPurchases - stockValue) / 0.29,
  )
  const [openingStock, setOpeningStock] = useState(Math.round(calculatedOpeningStock))
  const [purchases, setPurchases] = useState(Math.round(calculatedPurchases))
  const [closingStock, setClosingStock] = useState(Math.round(stockValue))
  const [revenue, setRevenue] = useState(Math.round(suggestedRevenue))
  const nextMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
  const nextMonthName = nextMonth.toLocaleDateString('pt-BR', { month: 'long' })
  const nextMonthIndex = nextMonth.getMonth()
  const defaultSeason = [11, 0, 1].includes(nextMonthIndex) ? 'high' : 'regular'
  const [season, setSeason] = useState(defaultSeason)
  const seasonality = {
    regular: { label: 'Operação regular', factor: 1, note: 'Demanda dentro da média histórica.' },
    high: {
      label: 'Alta temporada',
      factor: 1.24,
      note: 'Verão, férias e maior fluxo turístico em Santos.',
    },
    holiday: {
      label: 'Festas e eventos',
      factor: 1.36,
      note: 'Celebrações, feriados prolongados e eventos fechados.',
    },
    low: {
      label: 'Baixa temporada',
      factor: 0.82,
      note: 'Fluxo reduzido e compras mais conservadoras.',
    },
  } as const
  const selectedSeason = seasonality[season as keyof typeof seasonality]
  const cmv = Math.max(0, openingStock + purchases - closingStock)
  const cmvRate = revenue > 0 ? (cmv / revenue) * 100 : 0
  const monthlyConsumptionBase = Math.max(monthlyExitsValue, cmv * 0.72)
  const projectedConsumption = monthlyConsumptionBase * selectedSeason.factor
  const projectedPurchases = Math.max(0, projectedConsumption + closingStock * 0.2)

  return (
    <>
      <PageTitle
        kicker="INTELIGÊNCIA OPERACIONAL"
        title={isOwner ? 'Relatórios & CMV' : 'Relatórios'}
        text="Indicadores de estoque, consumo e perdas disponíveis à gestão."
      />
      {isOwner && (
        <section className="owner-intelligence">
          <article className="panel cmv-card">
            <div className="report-card-head">
              <div>
                <span className="section-kicker">CUSTO DA MERCADORIA VENDIDA</span>
                <h2>Calculadora de CMV</h2>
              </div>
              <span className="report-icon">
                <Calculator size={20} />
              </span>
            </div>
            <div className="cmv-formula">
              <label>
                <span>Estoque inicial do mês</span>
                <input
                  type="number"
                  min="0"
                  value={openingStock}
                  onChange={(event) => setOpeningStock(Number(event.target.value))}
                />
              </label>
              <i>+</i>
              <label>
                <span>Compras durante o mês</span>
                <input
                  type="number"
                  min="0"
                  value={purchases}
                  onChange={(event) => setPurchases(Number(event.target.value))}
                />
              </label>
              <i>−</i>
              <label>
                <span>Estoque final do mês</span>
                <input
                  type="number"
                  min="0"
                  value={closingStock}
                  onChange={(event) => setClosingStock(Number(event.target.value))}
                />
              </label>
              <i>=</i>
              <div className="cmv-result">
                <span>CMV calculado</span>
                <strong>{money(cmv)}</strong>
              </div>
            </div>
            <div className="cmv-rate">
              <label>
                <span>Faturamento do período</span>
                <input
                  type="number"
                  min="0"
                  value={revenue}
                  onChange={(event) => setRevenue(Number(event.target.value))}
                />
              </label>
              <div>
                <span>CMV sobre faturamento</span>
                <strong>{cmvRate.toFixed(1).replace('.', ',')}%</strong>
                <small>Referência saudável sugerida: 28% a 35%</small>
              </div>
            </div>
            <p className="cmv-source-note">
              Resumo do mês atual: estoque inicial é reconstruído pelo saldo e movimentos; compras
              usam entradas com custo ou, na ausência delas, os comprovantes do mês; estoque final
              usa o saldo atual. Ajuste apenas para conciliação contábil.
            </p>
          </article>
          <article className="panel projection-card">
            <div className="report-card-head">
              <div>
                <span className="section-kicker">PROJEÇÃO SAZONAL</span>
                <h2>Próximo mês</h2>
              </div>
              <span className="report-icon">
                <TrendingUp size={20} />
              </span>
            </div>
            <div className="projection-content">
              <span className="projection-month">{nextMonthName}</span>
              <label className="form-field">
                <span>Cenário esperado</span>
                <select value={season} onChange={(event) => setSeason(event.target.value)}>
                  {Object.entries(seasonality).map(([value, option]) => (
                    <option value={value} key={value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
              <p>{selectedSeason.note}</p>
              <div className="projection-values">
                <span>
                  <small>Consumo projetado</small>
                  <strong>{money(projectedConsumption)}</strong>
                </span>
                <span>
                  <small>Sugestão de compras</small>
                  <strong>{money(projectedPurchases)}</strong>
                </span>
              </div>
              <small className="projection-disclaimer">
                Simulação baseada no CMV, nas baixas recentes e em um fator sazonal ajustável.
              </small>
            </div>
          </article>
        </section>
      )}
      <section className="report-metrics">
        <article>
          <span>Valor em estoque</span>
          <strong>{money(stockValue)}</strong>
          <small className="positive">Saldo atual</small>
        </article>
        <article>
          <span>Baixas registradas</span>
          <strong>{exits.length}</strong>
          <small>Histórico recente</small>
        </article>
        <article>
          <span>Perdas e descartes</span>
          <strong>{lossMovements.length}</strong>
          <small className="positive">Média por ocorrência: {money(averageWaste)}</small>
        </article>
        <article>
          <span>Itens abaixo do mínimo</span>
          <strong>
            {products.filter((product) => product.quantity <= product.minimumStock).length}
          </strong>
          <small>Ação recomendada</small>
        </article>
      </section>
      <section className="reports-grid">
        <article className="panel consumption-chart">
          <div className="report-card-head">
            <div>
              <span className="section-kicker">EVOLUÇÃO MENSAL</span>
              <h2>Consumo por categoria</h2>
            </div>
            <div className="chart-legend">
              <span>
                <i /> Alimentos
              </span>
              <span>
                <i /> Bebidas
              </span>
            </div>
          </div>
          <div className="bar-chart" aria-label="Gráfico de consumo mensal">
            {chart.map((height, index) => (
              <div key={index}>
                <span style={{ height: `${height}%` }} />
                <i style={{ height: `${Math.max(25, height - 22)}%` }} />
                <small>{['Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'][index]}</small>
              </div>
            ))}
          </div>
        </article>
        <article className="panel loss-card">
          <div className="report-card-head">
            <div>
              <span className="section-kicker">PERDAS</span>
              <h2>Motivos de descarte</h2>
            </div>
          </div>
          <div className="donut-wrap">
            <div className="donut">
              <strong>{exits.length}</strong>
              <span>baixas</span>
            </div>
            <div className="donut-list">
              {[
                ['Consumo', '44%', '#376759'],
                ['Avaria', '29%', '#b9995b'],
                ['Validade', '17%', '#a54e44'],
                ['Outros', '10%', '#c7cbc7'],
              ].map(([label, value, color]) => (
                <div key={label}>
                  <i style={{ background: color }} />
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
            </div>
          </div>
        </article>
        <article className="panel responsible-report">
          <div className="report-card-head">
            <div>
              <span className="section-kicker">RASTREABILIDADE</span>
              <h2>Quem registrou as baixas</h2>
            </div>
          </div>
          {exits.length ? (
            exits.slice(0, 8).map((movement) => {
              const product = typeof movement.product === 'object' ? movement.product : null
              const createdBy =
                typeof movement.createdBy === 'object' ? movement.createdBy.name : 'Responsável'
              return (
                <div className="responsible-row" key={movement.id}>
                  <span>
                    <strong>{createdBy}</strong>
                    <small>
                      {movement.operationalArea
                        ? areaLabels[movement.operationalArea]
                        : 'Gestão de estoque'}
                    </small>
                  </span>
                  <span>
                    <strong>{product?.name || 'Insumo'}</strong>
                    <small>{movement.reason}</small>
                  </span>
                  <b>
                    −{movement.quantity} {movement.unit}
                  </b>
                </div>
              )
            })
          ) : (
            <EmptyState text="Nenhuma baixa registrada" />
          )}
        </article>
      </section>
    </>
  )
}

function Team({ team, onDone }: { team: TeamMember[]; onDone: (result: ActionResult) => void }) {
  return (
    <>
      <PageTitle
        kicker="GESTÃO DE ACESSOS"
        title="Equipe"
        text="Crie e gerencie login, senha, função e disponibilidade de cada funcionário."
      />
      <section className="team-layout">
        <article className="panel credentials-card">
          <div className="settings-card-head">
            <span>
              <UsersRound size={20} />
            </span>
            <div>
              <h2>Novo funcionário</h2>
              <p>O acesso será individual e respeitará o perfil escolhido.</p>
            </div>
          </div>
          <ActionForm action={createEmployeeAction} onDone={onDone}>
            <div className="form-grid">
              <label className="form-field">
                <span>Nome</span>
                <input name="name" required />
              </label>
              <label className="form-field">
                <span>Função</span>
                <input name="function" required placeholder="Ex.: Cozinheiro, bartender..." />
              </label>
              <label className="form-field">
                <span>E-mail de login</span>
                <input name="email" type="email" required />
              </label>
              <label className="form-field">
                <span>Senha inicial</span>
                <input name="password" type="password" minLength={4} required />
              </label>
              <label className="form-field full-width">
                <span>Perfil de acesso</span>
                <select name="role" defaultValue="operational">
                  <option value="operational">Equipe operacional</option>
                  <option value="storekeeper">Almoxarife</option>
                </select>
              </label>
            </div>
          </ActionForm>
        </article>
        <article className="panel team-list">
          <div className="section-heading compact">
            <div>
              <span className="section-kicker">ACESSOS ATIVOS</span>
              <h2>Funcionários</h2>
            </div>
            <span className="count-badge">{team.length}</span>
          </div>
          {team.map((member) => (
            <article
              className={`team-row ${member.active === false ? 'is-inactive' : ''}`}
              key={member.id}
            >
              <i>{member.name.slice(0, 2).toUpperCase()}</i>
              <div>
                <strong>{member.name}</strong>
                <small>
                  {member.function || roleLabels[member.role]} · {member.email}
                </small>
              </div>
              <span>{member.active === false ? 'Inativo' : roleLabels[member.role]}</span>
              {member.role !== 'owner' && (
                <details className="record-editor">
                  <summary>Gerenciar acesso</summary>
                  <ActionForm action={updateEmployeeAction} onDone={onDone}>
                    <input type="hidden" name="id" value={member.id} />
                    <div className="form-grid">
                      <label className="form-field">
                        <span>Nome</span>
                        <input name="name" defaultValue={member.name} required />
                      </label>
                      <label className="form-field">
                        <span>Função</span>
                        <select name="function" defaultValue={member.function || 'Cozinheiro'}>
                          <option>Cozinheiro</option>
                          <option>Bartender</option>
                          <option>Almoxarife</option>
                        </select>
                      </label>
                      <label className="form-field">
                        <span>E-mail</span>
                        <input name="email" type="email" defaultValue={member.email} required />
                      </label>
                      <label className="form-field">
                        <span>Nova senha (opcional)</span>
                        <input name="password" type="password" minLength={4} />
                      </label>
                      <label className="form-field">
                        <span>Perfil</span>
                        <select name="role" defaultValue={member.role}>
                          <option value="operational">Equipe operacional</option>
                          <option value="storekeeper">Almoxarife</option>
                        </select>
                      </label>
                      <label className="form-field">
                        <span>Situação</span>
                        <select
                          name="active"
                          defaultValue={member.active === false ? 'false' : 'true'}
                        >
                          <option value="true">Ativo</option>
                          <option value="false">Inativo</option>
                        </select>
                      </label>
                    </div>
                  </ActionForm>
                </details>
              )}
            </article>
          ))}
        </article>
      </section>
    </>
  )
}

function QrScanner({
  products,
  onDetected,
  managementMode,
}: {
  products: Product[]
  onDetected: (product: Product) => void
  managementMode: boolean
}) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const timerRef = useRef<number | null>(null)
  const detectingRef = useRef(false)
  const [active, setActive] = useState(false)
  const [status, setStatus] = useState(
    'Ative a câmera e aponte para uma etiqueta criada pelo SICE.',
  )
  const [manualProduct, setManualProduct] = useState('')
  const [simulating, setSimulating] = useState(false)

  const stopScanner = () => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current)
      timerRef.current = null
    }
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    if (videoRef.current) videoRef.current.srcObject = null
    setActive(false)
  }

  useEffect(
    () => () => {
      if (timerRef.current !== null) window.clearInterval(timerRef.current)
      streamRef.current?.getTracks().forEach((track) => track.stop())
    },
    [],
  )

  const findProduct = (rawValue: string) => {
    let reference = rawValue.trim()
    try {
      const decoded = JSON.parse(reference) as { product?: unknown; code?: unknown }
      if (typeof decoded.product === 'string') reference = decoded.product
      else if (typeof decoded.code === 'string') reference = decoded.code
    } catch {
      // Plain product codes are valid too.
    }
    return products.find(
      (product) =>
        product.code.toLowerCase() === reference.toLowerCase() || String(product.id) === reference,
    )
  }

  const completeDetection = (rawValue: string) => {
    const product = findProduct(rawValue)
    if (!product) {
      setStatus('QR Code lido, mas o insumo não foi encontrado neste estoque.')
      return
    }
    stopScanner()
    setStatus(
      `${product.name} identificado. ${managementMode ? 'Abrindo cadastro e histórico...' : 'Abrindo a baixa...'}`,
    )
    onDetected(product)
  }

  const detectorConstructor = () =>
    (window as typeof window & { BarcodeDetector?: QrDetectorConstructor }).BarcodeDetector

  const startScanner = async () => {
    const Detector = detectorConstructor()
    if (!Detector) {
      setStatus('A leitura automática não está disponível neste navegador. Use a seleção manual.')
      return
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus('Este dispositivo não disponibilizou acesso à câmera.')
      return
    }
    try {
      stopScanner()
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      })
      streamRef.current = stream
      if (!videoRef.current) return
      videoRef.current.srcObject = stream
      await videoRef.current.play()
      const detector = new Detector({ formats: inventoryCodeFormats })
      setActive(true)
      setStatus('Câmera ativa. Centralize o QR Code dentro da moldura.')
      timerRef.current = window.setInterval(async () => {
        if (!videoRef.current || videoRef.current.readyState < 2 || detectingRef.current) return
        detectingRef.current = true
        try {
          const codes = await detector.detect(videoRef.current)
          if (codes[0]?.rawValue) completeDetection(codes[0].rawValue)
        } catch {
          setStatus('Mantenha a etiqueta estável e bem iluminada.')
        } finally {
          detectingRef.current = false
        }
      }, 450)
    } catch {
      setStatus('Não foi possível acessar a câmera. Verifique a permissão do navegador.')
      stopScanner()
    }
  }

  const scanImage = async (file?: File) => {
    if (!file) return
    const Detector = detectorConstructor()
    if (!Detector) {
      setStatus('Este navegador não consegue ler QR Code de imagens. Use a seleção manual.')
      return
    }
    try {
      const bitmap = await createImageBitmap(file)
      const codes = await new Detector({ formats: inventoryCodeFormats }).detect(bitmap)
      bitmap.close()
      if (!codes[0]?.rawValue) {
        setStatus('Nenhum QR Code foi encontrado nessa imagem.')
        return
      }
      completeDetection(codes[0].rawValue)
    } catch {
      setStatus('Não foi possível analisar essa imagem.')
    }
  }

  const simulateScan = () => {
    const demoProduct =
      products.find((product) => /salmão|camarão|arroz/i.test(product.name)) || products[0]
    if (!demoProduct) {
      setStatus('Cadastre um insumo para executar a simulação.')
      return
    }
    stopScanner()
    setActive(true)
    setSimulating(true)
    setStatus(`Simulando leitura da etiqueta ${demoProduct.code}...`)
    window.setTimeout(() => {
      setSimulating(false)
      completeDetection(demoProduct.code)
    }, 1500)
  }

  return (
    <>
      <PageTitle
        kicker="BAIXA RÁPIDA"
        title="Ler código de barras ou QR"
        text={
          managementMode
            ? 'Identifique o insumo por código de barras ou QR para consultar, editar ou registrar movimentações.'
            : 'Identifique o insumo por código de barras ou QR e abra a baixa sem procurar no estoque.'
        }
      />
      <section className="scanner-layout">
        <article className="panel qr-reader-card">
          <div className="settings-card-head">
            <span>
              <QrCode size={21} />
            </span>
            <div>
              <h2>Leitor de etiquetas</h2>
              <p>A câmera traseira oferece a leitura mais rápida.</p>
            </div>
          </div>
          <div className={`qr-camera ${active ? 'is-active' : ''}`}>
            <video ref={videoRef} muted playsInline />
            {!active && (
              <div className="qr-camera-placeholder">
                <QrCode size={74} strokeWidth={1.25} />
                <span>Câmera desativada</span>
              </div>
            )}
            <div className="qr-scan-frame">
              <i />
            </div>
          </div>
          <p className="qr-reader-status" aria-live="polite">
            {status}
          </p>
          <div className="qr-reader-actions">
            <button className="btn btn--primary" type="button" onClick={startScanner}>
              <QrCode size={18} /> {active ? 'Reiniciar câmera' : 'Ativar câmera'}
            </button>
            <button
              className="btn btn--simulation"
              type="button"
              onClick={simulateScan}
              disabled={simulating || !products.length}
            >
              <TrendingUp size={17} /> {simulating ? 'Lendo etiqueta...' : 'Simular leitura'}
            </button>
            {active && (
              <button className="btn btn--light" type="button" onClick={stopScanner}>
                Parar
              </button>
            )}
            <label className="btn btn--light qr-upload-button">
              <Upload size={17} /> Ler imagem
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(event) => scanImage(event.target.files?.[0])}
              />
            </label>
          </div>
        </article>
        <aside className="panel qr-manual-card">
          <span className="section-kicker">ALTERNATIVA MANUAL</span>
          <h2>Selecionar insumo</h2>
          <p>
            Se a câmera não estiver disponível, escolha o insumo para abrir o mesmo fluxo de baixa.
          </p>
          <label className="form-field">
            <span>Insumo</span>
            <select
              value={manualProduct}
              onChange={(event) => setManualProduct(event.target.value)}
            >
              <option value="">Selecione um insumo</option>
              {products.map((product) => (
                <option value={product.id} key={product.id}>
                  {product.name} · {product.code}
                </option>
              ))}
            </select>
          </label>
          <button
            className="btn btn--primary"
            type="button"
            disabled={!manualProduct}
            onClick={() => {
              const product = products.find((item) => String(item.id) === manualProduct)
              if (product) onDetected(product)
            }}
          >
            {managementMode ? 'Consultar insumo' : 'Registrar baixa'} <ArrowRight size={17} />
          </button>
          <div className="qr-reader-tip">
            <Check size={16} />
            <span>O produto será preenchido automaticamente no formulário de baixa.</span>
          </div>
        </aside>
      </section>
    </>
  )
}

function Labels({
  products,
  onDone,
}: {
  products: Product[]
  onDone: (result: ActionResult) => void
}) {
  const activeProducts = products.filter((item) => item.active !== false)
  const [productId, setProductId] = useState(activeProducts[0] ? String(activeProducts[0].id) : '')
  const [quantity, setQuantity] = useState('')
  const [unit, setUnit] = useState<'UN' | 'KG' | 'G' | 'L' | 'ML'>('UN')
  const [handledAt, setHandledAt] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [lot, setLot] = useState('')
  const [responsibleName, setResponsibleName] = useState('')
  const [qr, setQr] = useState('')
  const [labelPng, setLabelPng] = useState('')
  const product = activeProducts.find((item) => String(item.id) === productId)
  const displayQuantity = quantity
    ? `${new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 3 }).format(Number(quantity))} ${unit}`
    : '—'

  const generate = async () => {
    if (
      !product ||
      !quantity ||
      Number(quantity) <= 0 ||
      !handledAt ||
      !expiryDate ||
      !lot.trim() ||
      !responsibleName.trim()
    ) {
      onDone({ ok: false, error: 'Preencha todos os campos para gerar a prévia.' })
      return
    }
    if (new Date(expiryDate).getTime() < new Date(handledAt).getTime()) {
      onDone({ ok: false, error: 'A validade não pode ser anterior à manipulação.' })
      return
    }
    const payload = {
      productId: product.id,
      productCode: product.code,
      productName: product.name,
      quantity: Number(quantity),
      unit,
      handledAt,
      expiryDate,
      lot: lot.trim(),
      responsibleName: responsibleName.trim(),
    }
    const qrData = await QRCode.toDataURL(JSON.stringify(payload), {
      errorCorrectionLevel: 'H',
      width: 420,
      margin: 1,
    })
    setQr(qrData)

    const canvas = document.createElement('canvas')
    canvas.width = 1350
    canvas.height = 900
    const context = canvas.getContext('2d')
    if (!context) return
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    const qrImage = new window.Image()
    qrImage.src = qrData
    await qrImage.decode()
    context.imageSmoothingEnabled = false
    context.drawImage(qrImage, 55, 95, 500, 500)
    context.fillStyle = '#111111'
    context.textAlign = 'center'
    context.font = '700 48px sans-serif'
    context.fillText(product.code, 305, 670)

    context.textAlign = 'left'
    context.font = '700 64px sans-serif'
    context.fillText(product.name, 635, 130, 650)
    context.font = '400 48px sans-serif'
    context.fillText(`Quantidade: ${displayQuantity}`, 635, 220)
    context.fillText(`Manip.: ${formatDate(handledAt)}`, 635, 310)
    context.font = '700 52px sans-serif'
    context.fillText(`VAL.: ${formatDate(expiryDate)}`, 635, 400)
    context.font = '400 44px sans-serif'
    context.fillText(`Lote: ${lot.trim()}`, 635, 490)
    context.fillStyle = '#555555'
    context.fillText(`Resp.: ${responsibleName.trim()}`, 635, 575)
    context.strokeStyle = '#d5d5d5'
    context.lineWidth = 3
    context.beginPath()
    context.moveTo(635, 690)
    context.lineTo(1285, 690)
    context.stroke()
    context.fillStyle = '#102d24'
    context.font = '700 58px sans-serif'
    context.fillText('SICE', 635, 790)
    context.fillStyle = '#6b746f'
    context.font = '400 34px sans-serif'
    context.fillText('Allto Al Mar · Controle de estoque', 805, 790)
    setLabelPng(canvas.toDataURL('image/png'))
  }

  return (
    <>
      <PageTitle
        kicker="IDENTIFICAÇÃO"
        title="Criar etiquetas"
        text="Selecione o insumo e registre quantidade, datas, lote e responsável pela manipulação."
      />
      <section className="qr-layout labels-layout">
        <article className="panel qr-builder">
          <div className="settings-card-head">
            <span>
              <QrCode size={20} />
            </span>
            <div>
              <h2>Configurar etiqueta</h2>
              <p>Os dados serão salvos e incorporados ao QR Code.</p>
            </div>
          </div>
          <ActionForm action={createLabelAction} onDone={onDone} className="qr-form">
            <label className="form-field full-width">
              <span>1. Insumo</span>
              <select
                name="product"
                value={productId}
                onChange={(e) => setProductId(e.target.value)}
                required
              >
                <option value="">Selecione um insumo</option>
                {activeProducts.map((item) => (
                  <option value={item.id} key={item.id}>
                    {item.name} · {item.code}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>2. Quantidade</span>
              <input
                name="quantity"
                type="number"
                min="0.001"
                step="0.001"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
                placeholder="Ex.: 0,300"
              />
            </label>
            <label className="form-field">
              <span>3. Unidade de medida</span>
              <select
                name="unit"
                value={unit}
                onChange={(e) => setUnit(e.target.value as typeof unit)}
                required
              >
                {(['UN', 'KG', 'G', 'L', 'ML'] as const).map((value) => (
                  <option value={value} key={value}>
                    {value}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>4. Data de manipulação</span>
              <input
                name="handledAt"
                type="date"
                value={handledAt}
                onChange={(e) => setHandledAt(e.target.value)}
                required
              />
            </label>
            <label className="form-field">
              <span>5. Data de validade</span>
              <input
                name="expiryDate"
                type="date"
                min={handledAt || undefined}
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                required
              />
            </label>
            <label className="form-field">
              <span>6. Lote</span>
              <input
                name="lot"
                value={lot}
                onChange={(e) => setLot(e.target.value)}
                required
                placeholder="Ex.: L-1105"
              />
            </label>
            <label className="form-field">
              <span>7. Responsável</span>
              <input
                name="responsibleName"
                value={responsibleName}
                onChange={(e) => setResponsibleName(e.target.value)}
                required
                placeholder="Digite o nome"
              />
            </label>
            <div className="label-form-actions full-width">
              <button className="btn btn--light" type="button" onClick={generate}>
                <QrCode size={17} /> Gerar prévia
              </button>
              <button className="btn btn--primary" type="submit">
                <Check size={17} /> Salvar etiqueta
              </button>
            </div>
          </ActionForm>
        </article>
        <aside className="panel qr-preview-card">
          <div className="preview-title">
            <span>PRÉVIA DE IMPRESSÃO</span>
            <small>Etiqueta 90 × 60 mm</small>
          </div>
          <div className="print-label">
            <div className="label-qr-column">
              {qr ? (
                <Image
                  src={qr}
                  alt={`QR Code da etiqueta de ${product?.name || 'insumo'}`}
                  width={420}
                  height={420}
                  unoptimized
                />
              ) : (
                <div className="qr-placeholder">
                  <QrCode size={62} />
                  <span>Preencha os campos e gere a prévia</span>
                </div>
              )}
              <strong>{product?.code || 'CÓDIGO'}</strong>
            </div>
            <div className="label-information">
              <h3>{product?.name || 'Nome do insumo'}</h3>
              <p>
                Quantidade: <strong>{displayQuantity}</strong>
              </p>
              <p>
                Manip.: <strong>{formatDate(handledAt)}</strong>
              </p>
              <p className="label-expiry">
                VAL.: <strong>{formatDate(expiryDate)}</strong>
              </p>
              <p>
                Lote: <strong>{lot || '—'}</strong>
              </p>
              <p className="label-responsible">
                Resp.: <strong>{responsibleName || '—'}</strong>
              </p>
              <footer>
                <b>SICE</b>
                <span>Allto Al Mar</span>
              </footer>
            </div>
          </div>
          <div className="qr-actions">
            {labelPng ? (
              <a
                className="btn btn--primary"
                href={labelPng}
                download={`etiqueta-${product?.name || 'insumo'}-${lot || 'lote'}.png`}
              >
                <Download size={17} /> Baixar PNG
              </a>
            ) : (
              <button className="btn btn--primary" disabled type="button">
                <Download size={17} /> Baixar PNG
              </button>
            )}
            <button className="btn btn--light" type="button" onClick={() => window.print()}>
              Imprimir
            </button>
          </div>
          <p>
            <Check size={15} /> QR Code e dados legíveis em uma etiqueta pronta para impressão.
          </p>
        </aside>
      </section>
    </>
  )
}

function Alerts({
  products,
  movements,
  onSelect,
}: {
  products: Product[]
  movements: Movement[]
  onSelect: (product: Product) => void
}) {
  const [filter, setFilter] = useState<'expiry' | 'stock'>('expiry')
  const expiryAlerts = products.filter(expiresSoon)
  const stockAlerts = products.filter((product) => product.quantity <= product.minimumStock)
  const alerts = filter === 'expiry' ? expiryAlerts : stockAlerts
  const noticeHistory = [
    ...products.flatMap((product) => {
      const notices: { id: string; title: string; text: string; date: string; type: string }[] = []
      const date = product.updatedAt || product.createdAt || new Date().toISOString()
      if (expiresSoon(product)) {
        notices.push({
          id: `expiry-${product.id}`,
          title: `${product.name} próximo do vencimento`,
          text: `${product.code} · ${product.expiryDate ? formatDate(product.expiryDate) : product.expiry || 'validade curta'}`,
          date,
          type: 'expiry',
        })
      }
      if (product.quantity <= product.minimumStock) {
        notices.push({
          id: `stock-${product.id}`,
          title: `${product.name} atingiu o estoque mínimo`,
          text: `${product.quantity} ${product.unit} disponíveis · mínimo de ${product.minimumStock} ${product.unit}`,
          date,
          type: 'stock',
        })
      }
      return notices
    }),
    ...movements
      .filter(
        (movement) => movement.type === 'exit' && /validade|avaria|outros/i.test(movement.reason),
      )
      .map((movement) => {
        const product = typeof movement.product === 'object' ? movement.product : null
        return {
          id: `movement-${movement.id}`,
          title: `${movement.reason}: ${product?.name || 'insumo'}`,
          text: `${movement.quantity} ${movement.unit} registrados por ${typeof movement.createdBy === 'object' ? movement.createdBy.name : 'responsável identificado'}`,
          date: movement.createdAt,
          type: 'movement',
        }
      }),
  ]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 20)

  return (
    <>
      <PageTitle
        kicker="PRIORIDADE OPERACIONAL"
        title="Alertas"
        text="Insumos próximos do vencimento ou abaixo da quantidade mínima."
      />
      <section className="alert-summary">
        <button
          className={filter === 'expiry' ? 'active' : ''}
          type="button"
          onClick={() => setFilter('expiry')}
        >
          <span className="alert-summary-icon expiry">
            <Clock3 size={21} />
          </span>
          <div>
            <span>Próximos do vencimento</span>
            <strong>{products.filter(expiresSoon).length}</strong>
            <small>prioridade PVPS</small>
          </div>
        </button>
        <button
          className={filter === 'stock' ? 'active' : ''}
          type="button"
          onClick={() => setFilter('stock')}
        >
          <span className="alert-summary-icon stock">
            <AlertTriangle size={21} />
          </span>
          <div>
            <span>Abaixo do mínimo</span>
            <strong>{products.filter((item) => item.quantity <= item.minimumStock).length}</strong>
            <small>reposição recomendada</small>
          </div>
        </button>
      </section>
      <section className="panel alert-list">
        <div className="section-heading">
          <div>
            <span className="section-kicker">AÇÃO RECOMENDADA</span>
            <h2>{filter === 'expiry' ? 'Próximos do vencimento' : 'Perto do estoque mínimo'}</h2>
            <p>Clique em um item para consultar compra, validade, saldo e localização.</p>
          </div>
        </div>
        <ProductRows products={alerts} onSelect={onSelect} />
      </section>
      <section className="panel alert-history">
        <div className="section-heading">
          <div>
            <span className="section-kicker">ÚLTIMOS REGISTROS</span>
            <h2>Histórico de avisos</h2>
            <p>Até 20 alertas recentes de estoque, validade e descarte.</p>
          </div>
          <span className="count-badge">{noticeHistory.length}</span>
        </div>
        {noticeHistory.length ? (
          <div className="alert-history-list">
            {noticeHistory.map((notice) => (
              <article key={notice.id}>
                <span className={`alert-history-icon ${notice.type}`}>
                  {notice.type === 'expiry' ? (
                    <Clock3 size={17} />
                  ) : notice.type === 'stock' ? (
                    <AlertTriangle size={17} />
                  ) : (
                    <History size={17} />
                  )}
                </span>
                <div>
                  <strong>{notice.title}</strong>
                  <small>{notice.text}</small>
                </div>
                <time>{new Date(notice.date).toLocaleDateString('pt-BR')}</time>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState text="Nenhum aviso registrado" />
        )}
      </section>
    </>
  )
}

function ProductDetail({
  product,
  movements,
  canViewMoney,
  canManage,
  onDone,
  close,
  openMovement,
}: {
  product: Product
  movements: Movement[]
  canViewMoney: boolean
  canManage: boolean
  onDone: (result: ActionResult) => void
  close: () => void
  openMovement: (kind: 'entry' | 'exit') => void
}) {
  const lastEntry = movements.find(
    (movement) =>
      movement.type === 'entry' &&
      String(typeof movement.product === 'object' ? movement.product.id : movement.product) ===
        String(product.id),
  )
  const purchaseDate = product.purchasedAt || lastEntry?.createdAt || product.createdAt

  return (
    <>
      <button className="drawer-backdrop" onClick={close} aria-label="Fechar detalhes" />
      <aside className="detail-drawer">
        <div className="drawer-head">
          <div>
            <span>DETALHES DO INSUMO</span>
            <strong>{product.code}</strong>
          </div>
          <button className="icon-btn" onClick={close} aria-label="Fechar">
            <X size={20} />
          </button>
        </div>
        <div
          className="detail-hero"
          style={{ '--accent': product.accent || '#376759' } as CSSProperties}
        >
          <span>
            <Boxes size={30} />
          </span>
          <div>
            <small>{product.category}</small>
            <h2>{product.name}</h2>
            <span className={`status status--${product.status}`}>
              <i />
              {needsAttention(product) ? 'Requer atenção' : 'Saudável'}
            </span>
          </div>
        </div>
        <div className="stock-highlight">
          <div>
            <small>Estoque atual</small>
            <strong>
              {product.quantity} <em>{product.unit}</em>
            </strong>
          </div>
          <div>
            <small>Estoque mínimo</small>
            <strong>
              {product.minimumStock} <em>{product.unit}</em>
            </strong>
          </div>
        </div>
        <div className="detail-grid">
          <div>
            <span>Comprado em</span>
            <strong>{formatDate(purchaseDate)}</strong>
          </div>
          <div>
            <span>Vencimento</span>
            <strong>
              {product.expiryDate
                ? formatDate(product.expiryDate)
                : product.expiry || 'Não informado'}
            </strong>
          </div>
          <div>
            <span>Localização</span>
            <strong>{product.location}</strong>
          </div>
          <div>
            <span>Último fornecedor</span>
            <strong>{lastEntry?.supplier || 'Não informado'}</strong>
          </div>
          {canViewMoney && (
            <div>
              <span>Custo unitário</span>
              <strong>{money(product.unitCost || 0)}</strong>
            </div>
          )}
          <div>
            <span>Classificação do catálogo</span>
            <strong>
              {product.catalogType
                ? catalogTypeLabels[product.catalogType]
                : 'Classificação pendente'}
            </strong>
          </div>
        </div>
        <div className="lot-card">
          <div>
            <span>Orientação PVPS</span>
            <strong>{expiresSoon(product) ? 'Utilizar primeiro' : 'Prazo confortável'}</strong>
          </div>
          <div className="lot-progress">
            <i style={{ width: expiresSoon(product) ? '86%' : '38%' }} />
          </div>
          <small>Confira sempre a data impressa na embalagem.</small>
        </div>
        <div className="drawer-actions">
          <button className="btn btn--light" onClick={() => openMovement('entry')}>
            <ArrowDownLeft size={18} /> Entrada
          </button>
          <button className="btn btn--primary" onClick={() => openMovement('exit')}>
            <ArrowUpRight size={18} /> Registrar baixa
          </button>
        </div>
        {canManage && (
          <details className="record-editor product-editor">
            <summary>Editar cadastro do insumo</summary>
            <ActionForm action={updateProductAction} onDone={onDone}>
              <input type="hidden" name="id" value={product.id} />
              <div className="form-grid">
                <label className="form-field full-width">
                  <span>Nome</span>
                  <input name="name" defaultValue={product.name} required />
                </label>
                <label className="form-field">
                  <span>Código</span>
                  <input name="code" defaultValue={product.code} required />
                </label>
                <label className="form-field">
                  <span>Categoria</span>
                  <select name="category" defaultValue={inventoryGroup(product)}>
                    {inventoryGroups.map((group) => (
                      <option key={group}>{group}</option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>Classificação do catálogo</span>
                  <select name="catalogType" defaultValue={product.catalogType || ''}>
                    <option value="">Selecione</option>
                    {Object.entries(catalogTypeLabels).map(([value, label]) => (
                      <option value={value} key={value}>
                        {label}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>Local</span>
                  <input name="location" defaultValue={product.location} required />
                </label>
                <label className="form-field">
                  <span>Unidade</span>
                  <select name="unit" defaultValue={product.unit}>
                    {['kg', 'g', 'un', 'litros', 'caixa'].map((unit) => (
                      <option key={unit}>{unit}</option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>Estoque mínimo</span>
                  <input
                    name="minimumStock"
                    type="number"
                    min="0"
                    step="0.01"
                    defaultValue={product.minimumStock}
                    required
                  />
                </label>
                <label className="form-field">
                  <span>Custo unitário</span>
                  <input
                    name="unitCost"
                    type="number"
                    min="0"
                    step="0.01"
                    defaultValue={product.unitCost || 0}
                  />
                </label>
                <label className="form-field">
                  <span>Vencimento</span>
                  <input
                    name="expiryDate"
                    type="date"
                    defaultValue={product.expiryDate?.slice(0, 10) || ''}
                  />
                </label>
                <label className="form-field">
                  <span>Observação</span>
                  <input name="expiry" defaultValue={product.expiry || ''} />
                </label>
              </div>
            </ActionForm>
            <div className="record-actions">
              <ProductAvailabilityAction product={product} onDone={onDone} close={close} />
              <ConfirmAction
                action={deleteProductAction}
                id={product.id}
                label="Remover definitivamente"
                question="Remover definitivamente este insumo? Só será permitido se não houver histórico."
                onDone={(result) => {
                  onDone(result)
                  if (result.ok) close()
                }}
              />
            </div>
          </details>
        )}
      </aside>
    </>
  )
}

function Account({ user }: { user: AppUser }) {
  return (
    <>
      <PageTitle
        kicker="SEGURANÇA DA CONTA"
        title="Perfil e permissões"
        text="Não há alternância de conta: cada pessoa usa seu próprio login."
      />
      <section className="security-layout">
        <article className="panel access-card">
          <div className="access-icon">
            <UserRound size={25} />
          </div>
          <span>SEU NÍVEL DE ACESSO</span>
          <h2>{roleLabels[user.role]}</h2>
          <p>
            {user.role === 'owner'
              ? 'Acesso completo a compras, relatórios, equipe e operação.'
              : user.role === 'storekeeper'
                ? 'Acesso a compras, relatórios, cadastros e movimentações.'
                : 'Acesso à rotina operacional e criação de etiquetas.'}
          </p>
          <div className="permission-list">
            <span>
              <Check size={14} /> Movimentar estoque
            </span>
            <span>
              <Check size={14} /> Criar etiquetas
            </span>
            {user.role !== 'operational' && (
              <span>
                <Check size={14} /> Cadastrar e nomear insumos
              </span>
            )}
            {user.role === 'owner' && (
              <span>
                <Check size={14} /> Gerenciar equipe
              </span>
            )}
          </div>
          <LogoutButton className="profile-logout-button" />
        </article>
      </section>
    </>
  )
}

function MovementModal({
  kind,
  products,
  user,
  initialProductId,
  close,
  onDone,
}: {
  kind: 'product' | 'entry' | 'exit'
  products: Product[]
  user: AppUser
  initialProductId?: string
  close: () => void
  onDone: (result: ActionResult) => void
}) {
  const [reason, setReason] = useState('')
  const productForm = kind === 'product'
  return (
    <div className="modal-layer" role="dialog" aria-modal="true">
      <button className="modal-backdrop" onClick={close} aria-label="Fechar" />
      <div className="modal-card">
        <div className="modal-head">
          <div className="modal-icon">
            {productForm ? <Plus /> : kind === 'entry' ? <ArrowDownLeft /> : <ArrowUpRight />}
          </div>
          <div>
            <span>{productForm ? 'CADASTRO DE INSUMO' : 'MOVIMENTAÇÃO DE ESTOQUE'}</span>
            <h2>
              {productForm
                ? 'Novo insumo'
                : kind === 'entry'
                  ? 'Registrar entrada'
                  : 'Registrar baixa'}
            </h2>
          </div>
          <button className="icon-btn" onClick={close}>
            <X size={20} />
          </button>
        </div>
        <ActionForm
          action={productForm ? createProductAction : createMovementAction}
          onDone={onDone}
        >
          {!productForm && <input type="hidden" name="type" value={kind} />}
          {productForm ? (
            <div className="form-grid">
              <label className="form-field full-width">
                <span>Nome do novo insumo</span>
                <input
                  name="name"
                  required
                  autoFocus
                  placeholder="Digite livremente o nome do insumo"
                />
              </label>
              <label className="form-field">
                <span>Código</span>
                <input name="code" required placeholder="INS-0001" />
              </label>
              <label className="form-field">
                <span>Categoria</span>
                <select name="category" required defaultValue="Hortifrúti">
                  {inventoryGroups.map((group) => (
                    <option key={group}>{group}</option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Classificação do catálogo</span>
                <select name="catalogType" required defaultValue="perishable">
                  {Object.entries(catalogTypeLabels).map(([value, label]) => (
                    <option value={value} key={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Local</span>
                <input name="location" required />
              </label>
              <label className="form-field">
                <span>Quantidade inicial</span>
                <input name="quantity" type="number" min="0" step="0.01" required />
              </label>
              <label className="form-field">
                <span>Unidade</span>
                <select name="unit">
                  <option>kg</option>
                  <option>g</option>
                  <option>un</option>
                  <option>litros</option>
                  <option>caixa</option>
                </select>
              </label>
              <label className="form-field">
                <span>Estoque mínimo</span>
                <input name="minimumStock" type="number" min="0" step="0.01" required />
              </label>
              <label className="form-field">
                <span>Custo unitário</span>
                <input name="unitCost" type="number" min="0" step="0.01" />
              </label>
              <label className="form-field">
                <span>Data da compra</span>
                <input name="purchasedAt" type="date" />
              </label>
              <label className="form-field">
                <span>Data de vencimento</span>
                <input name="expiryDate" type="date" />
              </label>
              <label className="form-field full-width">
                <span>Observação de validade</span>
                <input name="expiry" placeholder="Ex.: consumir em até 30 dias" />
              </label>
            </div>
          ) : (
            <div className="form-grid">
              <label className="form-field full-width">
                <span>Insumo</span>
                <select name="product" required defaultValue={initialProductId || ''}>
                  <option value="" disabled>
                    Selecione um insumo já cadastrado
                  </option>
                  {products.map((product) => (
                    <option value={product.id} key={product.id}>
                      {product.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Quantidade</span>
                <input name="quantity" type="number" min="0.01" step="0.01" required />
              </label>
              <label className="form-field">
                <span>Unidade</span>
                <select name="unit">
                  <option>kg</option>
                  <option>g</option>
                  <option>un</option>
                  <option>litros</option>
                  <option>caixa</option>
                </select>
              </label>
              {kind === 'entry' ? (
                <>
                  <label className="form-field">
                    <span>Fornecedor</span>
                    <input name="supplier" required />
                  </label>
                  <label className="form-field">
                    <span>Data de recebimento</span>
                    <input
                      name="receivedDate"
                      type="date"
                      defaultValue={new Date().toISOString().slice(0, 10)}
                      required
                    />
                  </label>
                  <label className="form-field">
                    <span>Custo unitário</span>
                    <input name="unitCost" type="number" min="0" step="0.01" required />
                  </label>
                  <label className="form-field">
                    <span>Data de vencimento</span>
                    <input name="expiryDate" type="date" />
                  </label>
                </>
              ) : (
                <label className="form-field full-width">
                  <span>Motivo da baixa</span>
                  <select
                    name="reason"
                    required
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  >
                    <option value="" disabled>
                      Selecione o motivo
                    </option>
                    <option value="Consumo">Consumo</option>
                    <option value="Validade">Validade</option>
                    <option value="Avaria">Avaria</option>
                    <option value="Outros">Outros — especificar</option>
                  </select>
                </label>
              )}
              {kind === 'entry' && (
                <input type="hidden" name="reason" value="Recebimento de fornecedor" />
              )}
              {kind === 'exit' && user.role === 'operational' && (
                <label className="form-field full-width">
                  <span>Identificação operacional</span>
                  <select name="operationalArea" required defaultValue="">
                    <option value="" disabled>
                      Selecione quem está registrando
                    </option>
                    <option value="kitchen">Cozinha</option>
                    <option value="bar">Bar</option>
                  </select>
                </label>
              )}
              {kind === 'exit' && reason === 'Outros' && (
                <label className="form-field full-width">
                  <span>Descreva o motivo</span>
                  <textarea
                    name="otherReason"
                    required
                    rows={3}
                    placeholder="Explique por que o produto está sendo descartado..."
                  />
                </label>
              )}
            </div>
          )}
          <div className="responsible-note">
            <UserRound size={17} />
            <span>
              Responsável:{' '}
              <strong>
                {user.name} · {roleLabels[user.role]}
              </strong>
            </span>
            <Check size={16} />
          </div>
        </ActionForm>
      </div>
    </div>
  )
}
