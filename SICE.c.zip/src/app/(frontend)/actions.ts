'use server'

import config from '@payload-config'
import { getPayload } from 'payload'
import { appAuth } from '@/lib/app-auth'

export type ActionResult = { ok: true; message: string } | { ok: false; error: string }

const text = (form: FormData, key: string, max = 160) => {
  const value = form.get(key)
  return typeof value === 'string' ? value.trim().slice(0, max) : ''
}

const number = (form: FormData, key: string) => {
  const value = Number(form.get(key))
  return Number.isFinite(value) ? value : NaN
}

const errorMessage = (error: unknown) =>
  error instanceof Error && error.message ? error.message : 'Não foi possível concluir a ação.'

async function context() {
  const user = await appAuth.currentUser()
  if (!user) throw new Error('Sua sessão expirou. Entre novamente.')
  return { payload: await getPayload({ config }), user }
}

const manager = (role: string) => role === 'owner' || role === 'storekeeper'

const id = (form: FormData) => text(form, 'id', 120)
const catalogType = (form: FormData) => {
  const value = text(form, 'catalogType')
  return ['perishable', 'non-perishable', 'beverage', 'disposable'].includes(value)
    ? (value as 'perishable' | 'non-perishable' | 'beverage' | 'disposable')
    : undefined
}

export async function createEmployeeAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (user.role !== 'owner')
      return { ok: false, error: 'Apenas o proprietário gerencia a equipe.' }
    const name = text(form, 'name')
    const email = text(form, 'email', 254).toLowerCase()
    const password = text(form, 'password', 128)
    const role = text(form, 'role') as 'storekeeper' | 'operational'
    const employeeFunction = text(form, 'function')
    if (!name || !email || password.length < 4 || !['storekeeper', 'operational'].includes(role)) {
      return { ok: false, error: 'Revise nome, e-mail, função, perfil e senha.' }
    }
    await payload.create({
      collection: 'users',
      data: { name, email, password, role, function: employeeFunction, active: true },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Novo acesso criado para o funcionário.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function createProductAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (user.role === 'operational')
      return { ok: false, error: 'Seu perfil apenas seleciona insumos existentes.' }
    const name = text(form, 'name')
    const quantity = number(form, 'quantity')
    const minimumStock = number(form, 'minimumStock')
    const unitCost = number(form, 'unitCost')
    if (!name || !Number.isFinite(quantity) || !Number.isFinite(minimumStock)) {
      return { ok: false, error: 'Preencha os campos obrigatórios do insumo.' }
    }
    await payload.create({
      collection: 'inventory-products',
      data: {
        name,
        category: text(form, 'category'),
        catalogType: catalogType(form),
        code: text(form, 'code').toUpperCase(),
        location: text(form, 'location'),
        quantity,
        unit: text(form, 'unit') as 'kg' | 'g' | 'un' | 'litros' | 'caixa',
        minimumStock,
        unitCost: Number.isFinite(unitCost) ? unitCost : 0,
        active: true,
        expiry: text(form, 'expiry'),
        purchasedAt: text(form, 'purchasedAt') || undefined,
        expiryDate: text(form, 'expiryDate') || undefined,
        status: quantity <= minimumStock ? 'low' : 'ok',
        accent: '#376759',
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Insumo cadastrado com sucesso.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function createMovementAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    const type = text(form, 'type')
    const product = text(form, 'product')
    const quantity = number(form, 'quantity')
    const reason = text(form, 'reason')
    const otherReason = text(form, 'otherReason', 500)
    const operationalArea = text(form, 'operationalArea')
    if (!product || !['entry', 'exit'].includes(type) || quantity <= 0 || !reason) {
      return { ok: false, error: 'Preencha produto, quantidade e motivo.' }
    }
    if (type === 'entry' && !manager(user.role)) {
      return { ok: false, error: 'Apenas a gestão de estoque registra entradas.' }
    }
    if (reason === 'Outros' && !otherReason) {
      return { ok: false, error: 'Descreva o motivo da baixa.' }
    }
    if (
      user.role === 'operational' &&
      type === 'exit' &&
      !['kitchen', 'bar'].includes(operationalArea)
    ) {
      return { ok: false, error: 'Selecione cozinha ou bar.' }
    }
    await payload.create({
      collection: 'inventory-movements',
      data: {
        product,
        type: type as 'entry' | 'exit',
        quantity,
        unit: text(form, 'unit'),
        reason,
        otherReason: reason === 'Outros' ? otherReason : undefined,
        supplier: type === 'entry' ? text(form, 'supplier') : undefined,
        receivedDate: type === 'entry' ? text(form, 'receivedDate') || undefined : undefined,
        unitCost:
          type === 'entry' && Number.isFinite(number(form, 'unitCost'))
            ? number(form, 'unitCost')
            : undefined,
        expiryDate: type === 'entry' ? text(form, 'expiryDate') || undefined : undefined,
        operationalArea:
          user.role === 'operational' && type === 'exit'
            ? (operationalArea as 'kitchen' | 'bar')
            : undefined,
        createdBy: user.id,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: type === 'entry' ? 'Entrada registrada.' : 'Baixa registrada.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function updateProductAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Acesso restrito à gestão de estoque.' }
    const productID = id(form)
    const name = text(form, 'name')
    const minimumStock = number(form, 'minimumStock')
    const unitCost = number(form, 'unitCost')
    if (!productID || !name || minimumStock < 0) {
      return { ok: false, error: 'Revise nome e estoque mínimo.' }
    }
    await payload.update({
      collection: 'inventory-products',
      id: productID,
      data: {
        name,
        category: text(form, 'category'),
        catalogType: catalogType(form),
        code: text(form, 'code').toUpperCase(),
        location: text(form, 'location'),
        unit: text(form, 'unit') as 'kg' | 'g' | 'un' | 'litros' | 'caixa',
        minimumStock,
        unitCost: Number.isFinite(unitCost) ? unitCost : 0,
        expiry: text(form, 'expiry'),
        expiryDate: text(form, 'expiryDate') || undefined,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Insumo atualizado.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function setProductActiveAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Acesso restrito à gestão de estoque.' }
    await payload.update({
      collection: 'inventory-products',
      id: id(form),
      data: { active: text(form, 'active') === 'true' },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Disponibilidade do insumo atualizada.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function deleteProductAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Acesso restrito à gestão de estoque.' }
    const productID = id(form)
    const related = await payload.find({
      collection: 'inventory-movements',
      where: { product: { equals: productID } },
      limit: 1,
      overrideAccess: false,
      user,
    })
    if (related.totalDocs) {
      return {
        ok: false,
        error: 'Este insumo possui histórico. Inative-o para preservar a rastreabilidade.',
      }
    }
    await payload.delete({
      collection: 'inventory-products',
      id: productID,
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Insumo sem histórico removido.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function updateEntryAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Acesso restrito à gestão de estoque.' }
    const quantity = number(form, 'quantity')
    const unitCost = number(form, 'unitCost')
    if (!id(form) || quantity <= 0) return { ok: false, error: 'Informe uma quantidade válida.' }
    await payload.update({
      collection: 'inventory-movements',
      id: id(form),
      data: {
        quantity,
        unit: text(form, 'unit'),
        supplier: text(form, 'supplier'),
        receivedDate: text(form, 'receivedDate') || undefined,
        unitCost: Number.isFinite(unitCost) ? unitCost : undefined,
        expiryDate: text(form, 'expiryDate') || undefined,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Entrada atualizada e saldo recalculado.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function deleteMovementAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Acesso restrito à gestão de estoque.' }
    await payload.delete({
      collection: 'inventory-movements',
      id: id(form),
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Registro removido e saldo recalculado.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function updateEmployeeAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (user.role !== 'owner')
      return { ok: false, error: 'Apenas o proprietário gerencia a equipe.' }
    const employeeID = id(form)
    const role = text(form, 'role') as 'storekeeper' | 'operational'
    if (!employeeID || !['storekeeper', 'operational'].includes(role)) {
      return { ok: false, error: 'Selecione um perfil válido.' }
    }
    const password = text(form, 'password', 128)
    await payload.update({
      collection: 'users',
      id: employeeID,
      data: {
        name: text(form, 'name'),
        email: text(form, 'email', 254).toLowerCase(),
        role,
        function: text(form, 'function'),
        active: text(form, 'active') === 'true',
        ...(password ? { password } : {}),
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Acesso do funcionário atualizado.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function createPurchaseOrderAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Seu perfil não acessa compras.' }
    const quantity = number(form, 'quantity')
    const unitCost = number(form, 'unitCost')
    if (!text(form, 'title') || quantity <= 0 || !text(form, 'expectedDate')) {
      return { ok: false, error: 'Revise item, quantidade e data prevista.' }
    }
    await payload.create({
      collection: 'purchase-orders',
      data: {
        title: text(form, 'title'),
        product: text(form, 'product') || undefined,
        supplier: text(form, 'supplier'),
        quantity,
        unit: text(form, 'unit') as 'kg' | 'g' | 'un' | 'litros' | 'caixa',
        unitCost: Number.isFinite(unitCost) ? unitCost : undefined,
        expectedDate: text(form, 'expectedDate'),
        status: 'planned',
        notes: text(form, 'notes', 500),
        createdBy: user.id,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Compra futura planejada.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function updatePurchaseOrderAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Seu perfil não acessa compras.' }
    const status = text(form, 'status') as 'planned' | 'ordered' | 'received' | 'cancelled'
    const quantity = number(form, 'quantity')
    const unitCost = number(form, 'unitCost')
    if (
      !text(form, 'title') ||
      quantity <= 0 ||
      !text(form, 'expectedDate') ||
      !['planned', 'ordered', 'received', 'cancelled'].includes(status)
    ) {
      return { ok: false, error: 'Revise item, quantidade, data e status.' }
    }
    await payload.update({
      collection: 'purchase-orders',
      id: id(form),
      data: {
        title: text(form, 'title'),
        product: text(form, 'product') || undefined,
        supplier: text(form, 'supplier'),
        quantity,
        unit: text(form, 'unit') as 'kg' | 'g' | 'un' | 'litros' | 'caixa',
        unitCost: Number.isFinite(unitCost) ? unitCost : undefined,
        expectedDate: text(form, 'expectedDate'),
        status,
        notes: text(form, 'notes', 500),
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Pedido de compra atualizado.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function deletePurchaseOrderAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (!manager(user.role)) return { ok: false, error: 'Seu perfil não acessa compras.' }
    await payload.delete({
      collection: 'purchase-orders',
      id: id(form),
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Planejamento de compra removido.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function createLabelAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    const productID = text(form, 'product')
    const quantity = number(form, 'quantity')
    const unit = text(form, 'unit') as 'UN' | 'KG' | 'G' | 'L' | 'ML'
    const handledAt = text(form, 'handledAt')
    const expiryDate = text(form, 'expiryDate')
    const lot = text(form, 'lot', 80)
    const responsibleName = text(form, 'responsibleName', 120)
    if (
      !productID ||
      quantity <= 0 ||
      !['UN', 'KG', 'G', 'L', 'ML'].includes(unit) ||
      !handledAt ||
      !expiryDate ||
      !lot ||
      !responsibleName
    ) {
      return { ok: false, error: 'Preencha todos os campos da etiqueta.' }
    }
    if (new Date(expiryDate).getTime() < new Date(handledAt).getTime()) {
      return { ok: false, error: 'A validade não pode ser anterior à manipulação.' }
    }
    const product = await payload.findByID({
      collection: 'inventory-products',
      id: productID,
      overrideAccess: false,
      user,
    })
    if (product.active === false) {
      return { ok: false, error: 'Selecione um insumo ativo.' }
    }
    await payload.create({
      collection: 'inventory-labels',
      data: {
        name: product.name,
        product: productID,
        quantity,
        unit,
        handledAt,
        expiryDate,
        lot,
        responsibleName,
        createdBy: user.id,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Etiqueta criada e guardada.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}

export async function uploadReceiptAction(form: FormData): Promise<ActionResult> {
  try {
    const { payload, user } = await context()
    if (user.role === 'operational') return { ok: false, error: 'Seu perfil não acessa compras.' }
    const uploaded = form.get('file')
    if (!(uploaded instanceof File) || uploaded.size === 0) {
      return { ok: false, error: 'Selecione uma foto ou PDF do comprovante.' }
    }
    if (uploaded.size > 10 * 1024 * 1024)
      return { ok: false, error: 'O arquivo deve ter até 10 MB.' }
    if (!['application/pdf', 'image/jpeg', 'image/png', 'image/webp'].includes(uploaded.type)) {
      return { ok: false, error: 'Envie PDF, JPG, PNG ou WEBP.' }
    }
    const amount = number(form, 'amount')
    await payload.create({
      collection: 'purchase-receipts',
      data: {
        title: text(form, 'title'),
        supplier: text(form, 'supplier'),
        purchaseDate: text(form, 'purchaseDate'),
        amount: Number.isFinite(amount) ? amount : undefined,
        uploadedBy: user.id,
      },
      file: {
        data: Buffer.from(await uploaded.arrayBuffer()),
        mimetype: uploaded.type,
        name: uploaded.name,
        size: uploaded.size,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Comprovante salvo na pasta de compras.' }
  } catch (error) {
    return { ok: false, error: errorMessage(error) }
  }
}
