import config from '@payload-config'
import { getPayload } from 'payload'
import { appAuth } from '@/lib/app-auth'
import { SiceApp } from './sice-app'

export const dynamic = 'force-dynamic'

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ login?: string | string[] }>
}) {
  const { login } = await searchParams
  const enteredAfterLogin = login === '1'

  if (!enteredAfterLogin)
    return <SiceApp user={null} products={[]} movements={[]} receipts={[]} orders={[]} team={[]} />

  const user = await appAuth.currentUser()
  if (!user)
    return <SiceApp user={null} products={[]} movements={[]} receipts={[]} orders={[]} team={[]} />

  const payload = await getPayload({ config })
  const canPurchase = user.role !== 'operational'
  const canManageTeam = user.role === 'owner'

  const [productsResult, movementsResult, receiptsResult, ordersResult, teamResult] =
    await Promise.all([
      payload.find({
        collection: 'inventory-products',
        limit: 100,
        sort: 'name',
        overrideAccess: false,
        user,
      }),
      payload.find({
        collection: 'inventory-movements',
        depth: 1,
        limit: 500,
        sort: '-createdAt',
        overrideAccess: false,
        user,
      }),
      canPurchase
        ? payload.find({
            collection: 'purchase-receipts',
            limit: 100,
            sort: '-purchaseDate',
            overrideAccess: false,
            user,
          })
        : Promise.resolve({ docs: [] }),
      canPurchase
        ? payload.find({
            collection: 'purchase-orders',
            depth: 1,
            limit: 50,
            sort: 'expectedDate',
            overrideAccess: false,
            user,
          })
        : Promise.resolve({ docs: [] }),
      canManageTeam
        ? payload.find({
            collection: 'users',
            limit: 100,
            sort: 'name',
            overrideAccess: false,
            user,
          })
        : Promise.resolve({ docs: [] }),
    ])

  return (
    <SiceApp
      user={user}
      products={productsResult.docs}
      movements={movementsResult.docs}
      receipts={receiptsResult.docs}
      orders={ordersResult.docs}
      team={teamResult.docs}
    />
  )
}
