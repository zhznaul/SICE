'use client'

export default function GlobalError({
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <html lang="pt-BR">
      <body>
        <main className="error-screen">
          <div className="error-card">
            <span>SICE</span>
            <h1>Não foi possível carregar o sistema.</h1>
            <p>Tente novamente. Se o problema continuar, encerre a sessão e acesse novamente.</p>
            <button type="button" onClick={reset}>
              Tentar novamente
            </button>
          </div>
        </main>
      </body>
    </html>
  )
}
