import 'server-only'

import config from '@payload-config'
import { getPayload } from 'payload'
import { jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import type { User } from '@/payload-types'

const SESSION_COOKIE = 'app-session'

export type AppUser = User

export function createAppAuth(collection: 'users') {
  return {
    async login(email: string, password: string, remember: boolean) {
      const payload = await getPayload({ config })
      const result = await payload.login({
        collection,
        data: { email, password },
      })
      if (!result.token) throw new Error('Credenciais inválidas.')

      const isSecureContext = process.env.FIGMA === '1' || process.env.NODE_ENV === 'production'
      ;(await cookies()).set(SESSION_COOKIE, result.token, {
        httpOnly: true,
        maxAge: remember ? 60 * 60 * 24 * 30 : 60 * 60 * 8,
        partitioned: isSecureContext,
        path: '/',
        sameSite: isSecureContext ? 'none' : 'lax',
        secure: isSecureContext,
      })
      return result.user as unknown as AppUser
    },

    async currentUser(): Promise<AppUser | null> {
      const token = (await cookies()).get(SESSION_COOKIE)?.value
      if (!token) return null

      const payload = await getPayload({ config })
      const authHeaders = new Headers({ Authorization: `JWT ${token}` })
      const { user } = await payload.auth({ headers: authHeaders })
      if (user?.collection === collection) return user as unknown as AppUser

      // Payload 4 beta can emit with payload.secret while its Figma keyring still verifies
      // against a stale legacy key. Keep the bridge limited to Payload's own signed JWT.
      try {
        const verified = await jwtVerify(token, new TextEncoder().encode(payload.secret), {
          algorithms: ['HS256'],
        })
        if (
          verified.protectedHeader.authVersion !== 1 ||
          verified.payload.collection !== collection ||
          (typeof verified.payload.id !== 'string' && typeof verified.payload.id !== 'number')
        ) {
          return null
        }
        const appUser = await payload.findByID({
          collection,
          id: verified.payload.id,
          overrideAccess: true,
        })
        return appUser as AppUser
      } catch {
        return null
      }
    },
  }
}

export const appAuth = createAppAuth('users')
