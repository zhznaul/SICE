import type { Access, CollectionConfig } from 'payload'
import type { AppRole } from './Users'

const purchasing: Access = ({ req }) => {
  const user = req.user as { collection?: string; role?: AppRole } | null
  return user?.collection === 'users' && (user.role === 'owner' || user.role === 'storekeeper')
}

export const PurchaseOrders: CollectionConfig = {
  slug: 'purchase-orders',
  admin: { group: 'Compras', useAsTitle: 'title' },
  access: {
    create: purchasing,
    delete: purchasing,
    read: purchasing,
    update: purchasing,
  },
  hooks: {
    beforeValidate: [
      ({ data, operation, req }) =>
        operation === 'create' && req.user?.collection === 'users'
          ? { ...data, createdBy: req.user.id }
          : data,
    ],
  },
  fields: [
    { name: 'title', type: 'text', required: true },
    {
      name: 'product',
      type: 'relationship',
      relationTo: 'inventory-products',
    },
    { name: 'supplier', type: 'text' },
    { name: 'quantity', type: 'number', required: true, min: 0.01 },
    {
      name: 'unit',
      type: 'select',
      required: true,
      options: ['kg', 'g', 'un', 'litros', 'caixa'],
    },
    { name: 'unitCost', type: 'number', min: 0 },
    { name: 'expectedDate', type: 'date', required: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'planned',
      options: [
        { label: 'Planejada', value: 'planned' },
        { label: 'Solicitada', value: 'ordered' },
        { label: 'Recebida', value: 'received' },
        { label: 'Cancelada', value: 'cancelled' },
      ],
    },
    { name: 'notes', type: 'textarea' },
    {
      name: 'createdBy',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: { create: () => false, update: () => false },
    },
  ],
}
