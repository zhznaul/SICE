import type { Access, CollectionConfig } from 'payload'

export type AppRole = 'owner' | 'storekeeper' | 'operational'

const appUser = (
  user: unknown,
): user is { collection: 'users'; id: string | number; role: AppRole } =>
  Boolean(user && typeof user === 'object' && 'collection' in user && user.collection === 'users')

const ownerOnly: Access = ({ req }) => appUser(req.user) && req.user.role === 'owner'
const ownerField = ({ req }: { req: { user: unknown } }) =>
  appUser(req.user) && req.user.role === 'owner'

export const Users: CollectionConfig = {
  slug: 'users',
  auth: {
    useSessions: false,
  },
  admin: {
    hidden: true,
    useAsTitle: 'name',
  },
  access: {
    create: ownerOnly,
    delete: ownerOnly,
    read: ({ req }) => {
      if (!appUser(req.user)) return false
      return req.user.role === 'owner' ? true : { id: { equals: req.user.id } }
    },
    update: ({ req }) => {
      if (!appUser(req.user)) return false
      return req.user.role === 'owner' ? true : { id: { equals: req.user.id } }
    },
  },
  fields: [
    { name: 'name', type: 'text', required: true },
    {
      name: 'role',
      type: 'select',
      required: true,
      options: [
        { label: 'Proprietário', value: 'owner' },
        { label: 'Almoxarife', value: 'storekeeper' },
        { label: 'Equipe operacional', value: 'operational' },
      ],
      access: { update: ownerField },
    },
    { name: 'function', type: 'text' },
    {
      name: 'active',
      type: 'checkbox',
      defaultValue: true,
      access: { update: ownerField },
    },
  ],
  hooks: {
    beforeLogin: [
      ({ user }) => {
        if (user.active === false) throw new Error('Este acesso está inativo.')
        return user
      },
    ],
  },
}
