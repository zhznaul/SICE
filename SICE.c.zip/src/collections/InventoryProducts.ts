import type { Access, CollectionConfig } from 'payload'
import type { AppRole } from './Users'

const appUser = (user: unknown): user is { collection: 'users'; role: AppRole } =>
  Boolean(user && typeof user === 'object' && 'collection' in user && user.collection === 'users')

const signedIn: Access = ({ req }) => appUser(req.user)
const inventoryManager: Access = ({ req }) =>
  appUser(req.user) && (req.user.role === 'owner' || req.user.role === 'storekeeper')

export const InventoryProducts: CollectionConfig = {
  slug: 'inventory-products',
  admin: { group: 'Operação', useAsTitle: 'name' },
  hooks: {
    beforeDelete: [
      async ({ id, req }) => {
        const movements = await req.payload.count({
          collection: 'inventory-movements',
          where: { product: { equals: id } },
          overrideAccess: true,
          req,
        })
        if (movements.totalDocs > 0) {
          throw new Error(
            'Este insumo possui histórico. Inative-o para preservar a rastreabilidade.',
          )
        }
      },
    ],
  },
  access: {
    create: inventoryManager,
    delete: inventoryManager,
    read: signedIn,
    update: inventoryManager,
  },
  fields: [
    { name: 'name', type: 'text', required: true },
    { name: 'category', type: 'text', required: true },
    {
      name: 'catalogType',
      type: 'select',
      options: [
        { label: 'Perecível', value: 'perishable' },
        { label: 'Não perecível', value: 'non-perishable' },
        { label: 'Bebida', value: 'beverage' },
        { label: 'Descartável', value: 'disposable' },
      ],
    },
    { name: 'code', type: 'text', required: true, unique: true, index: true },
    { name: 'location', type: 'text', required: true },
    { name: 'quantity', type: 'number', required: true, min: 0 },
    {
      name: 'unit',
      type: 'select',
      required: true,
      options: ['kg', 'g', 'un', 'litros', 'caixa'],
    },
    { name: 'minimumStock', type: 'number', required: true, min: 0 },
    { name: 'expiry', type: 'text' },
    { name: 'purchasedAt', type: 'date' },
    { name: 'expiryDate', type: 'date' },
    { name: 'unitCost', type: 'number', min: 0 },
    {
      name: 'active',
      type: 'checkbox',
      defaultValue: true,
      admin: { position: 'sidebar' },
    },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'ok',
      options: [
        { label: 'Saudável', value: 'ok' },
        { label: 'Estoque baixo', value: 'low' },
        { label: 'Prioridade PVPS', value: 'critical' },
      ],
    },
    { name: 'accent', type: 'text', defaultValue: '#376759' },
  ],
}
