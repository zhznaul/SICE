import type { Access, CollectionConfig } from 'payload'
import type { AppRole } from './Users'

const purchasing: Access = ({ req }) => {
  const user = req.user as { collection?: string; role?: AppRole } | null
  return user?.collection === 'users' && (user.role === 'owner' || user.role === 'storekeeper')
}

export const PurchaseReceipts: CollectionConfig = {
  slug: 'purchase-receipts',
  admin: { group: 'Compras', useAsTitle: 'title' },
  hooks: {
    beforeValidate: [
      ({ data, operation, req }) => {
        if (operation === 'create' && req.user?.collection === 'users') {
          return { ...data, uploadedBy: req.user.id }
        }
        return data
      },
    ],
  },
  access: {
    create: purchasing,
    delete: purchasing,
    read: purchasing,
    update: purchasing,
  },
  upload: {
    mimeTypes: ['application/pdf', 'image/*'],
    modifyResponseHeaders: ({ headers }) => {
      headers.set('Cache-Control', 'private, no-store')
      return headers
    },
  },
  fields: [
    { name: 'title', type: 'text', required: true },
    { name: 'supplier', type: 'text' },
    { name: 'purchaseDate', type: 'date', required: true },
    { name: 'amount', type: 'number', min: 0 },
    {
      name: 'uploadedBy',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: { create: () => false, update: () => false },
    },
  ],
}
