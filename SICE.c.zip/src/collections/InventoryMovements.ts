import type { Access, CollectionConfig, CollectionBeforeChangeHook, Validate } from 'payload'

const signedIn: Access = ({ req }) => req.user?.collection === 'users'
const inventoryManager: Access = ({ req }) =>
  req.user?.collection === 'users' && (req.user.role === 'owner' || req.user.role === 'storekeeper')
const validateOperationalArea: Validate<string> = (value, { req, siblingData }) => {
  const user = req.user as { collection?: string; role?: string } | null
  if (
    user?.collection === 'users' &&
    user.role === 'operational' &&
    siblingData.type === 'exit' &&
    !['kitchen', 'bar'].includes(value || '')
  ) {
    return 'Selecione cozinha ou bar.'
  }
  return true
}

const productID = (value: unknown) =>
  value && typeof value === 'object' && 'id' in value
    ? (value.id as string | number)
    : (value as string | number)

const signedQuantity = (movement: { type?: string; quantity?: number }) =>
  (movement.type === 'entry' ? 1 : -1) * Number(movement.quantity || 0)

const syncStock: CollectionBeforeChangeHook = async ({ data, operation, originalDoc, req }) => {
  if (req.context.skipInventorySync) return data
  const nextMovement = operation === 'update' ? { ...originalDoc, ...data } : data
  const nextProduct = productID(nextMovement.product)
  const previousProduct = operation === 'update' ? productID(originalDoc?.product) : null
  const deltas = new Map<string | number, number>()
  if (previousProduct) {
    deltas.set(previousProduct, (deltas.get(previousProduct) || 0) - signedQuantity(originalDoc))
  }
  deltas.set(nextProduct, (deltas.get(nextProduct) || 0) + signedQuantity(nextMovement))

  for (const [id, delta] of deltas) {
    if (!delta) continue
    const product = await req.payload.findByID({
      collection: 'inventory-products',
      id,
      overrideAccess: true,
      req,
    })
    const quantity = Number(product.quantity) + delta
    if (quantity < 0) throw new Error(`Saldo insuficiente para ${product.name}.`)
    await req.payload.update({
      collection: 'inventory-products',
      id,
      data: {
        quantity,
        status: quantity <= Number(product.minimumStock) ? 'low' : 'ok',
      },
      context: { skipInventorySync: true },
      overrideAccess: true,
      req,
    })
  }
  return data
}

export const InventoryMovements: CollectionConfig = {
  slug: 'inventory-movements',
  admin: { group: 'Operação', useAsTitle: 'reason' },
  hooks: {
    beforeValidate: [
      ({ data, operation, req }) => {
        if (operation === 'create' && req.user?.collection === 'users') {
          return { ...data, createdBy: req.user.id }
        }
        return data
      },
    ],
    beforeChange: [syncStock],
    beforeDelete: [
      async ({ id, req }) => {
        const movement = await req.payload.findByID({
          collection: 'inventory-movements',
          id,
          overrideAccess: true,
          req,
        })
        const product = await req.payload.findByID({
          collection: 'inventory-products',
          id: productID(movement.product),
          overrideAccess: true,
          req,
        })
        const quantity = Number(product.quantity) - signedQuantity(movement)
        if (quantity < 0) throw new Error('A exclusão deixaria o estoque com saldo negativo.')
        await req.payload.update({
          collection: 'inventory-products',
          id: product.id,
          data: {
            quantity,
            status: quantity <= Number(product.minimumStock) ? 'low' : 'ok',
          },
          context: { skipInventorySync: true },
          overrideAccess: true,
          req,
        })
      },
    ],
  },
  access: {
    create: ({ req, data }) =>
      req.user?.collection === 'users' &&
      (data?.type === 'exit' || req.user.role === 'owner' || req.user.role === 'storekeeper'),
    delete: inventoryManager,
    read: signedIn,
    update: inventoryManager,
  },
  fields: [
    {
      name: 'product',
      type: 'relationship',
      relationTo: 'inventory-products',
      required: true,
    },
    {
      name: 'type',
      type: 'select',
      required: true,
      options: [
        { label: 'Entrada', value: 'entry' },
        { label: 'Baixa', value: 'exit' },
      ],
    },
    { name: 'quantity', type: 'number', required: true, min: 0.01 },
    { name: 'unit', type: 'text', required: true },
    { name: 'reason', type: 'text', required: true },
    { name: 'otherReason', type: 'textarea' },
    { name: 'supplier', type: 'text' },
    { name: 'receivedDate', type: 'date' },
    { name: 'unitCost', type: 'number', min: 0 },
    { name: 'expiryDate', type: 'date' },
    {
      name: 'operationalArea',
      type: 'select',
      options: [
        { label: 'Cozinha', value: 'kitchen' },
        { label: 'Bar', value: 'bar' },
        { label: 'Almoxarife', value: 'storekeeper' },
      ],
      validate: validateOperationalArea,
    },
    {
      name: 'createdBy',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: { create: () => false, update: () => false },
    },
  ],
}
