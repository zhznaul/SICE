import type { Access, CollectionConfig } from 'payload'

const signedIn: Access = ({ req }) => req.user?.collection === 'users'

export const InventoryLabels: CollectionConfig = {
  slug: 'inventory-labels',
  admin: { group: 'Operação', useAsTitle: 'name' },
  hooks: {
    beforeValidate: [
      async ({ data, operation, req }) => {
        if (operation === 'create' && req.user?.collection === 'users') {
          const productID =
            data?.product && typeof data.product === 'object' && 'id' in data.product
              ? data.product.id
              : data?.product
          if (!productID) throw new Error('Selecione um insumo para gerar a etiqueta.')
          const product = await req.payload.findByID({
            collection: 'inventory-products',
            id: productID,
            overrideAccess: true,
            req,
          })
          if (product.active === false) {
            throw new Error('Selecione um insumo ativo para gerar a etiqueta.')
          }
          return { ...data, name: product.name, createdBy: req.user.id }
        }
        return data
      },
    ],
  },
  access: {
    create: signedIn,
    delete: signedIn,
    read: signedIn,
    update: signedIn,
  },
  fields: [
    {
      name: 'name',
      type: 'text',
      required: true,
      access: { create: () => false, update: () => false },
    },
    {
      name: 'product',
      type: 'relationship',
      relationTo: 'inventory-products',
      required: true,
    },
    { name: 'quantity', type: 'number', required: true, min: 0.01 },
    {
      name: 'unit',
      type: 'select',
      required: true,
      options: ['UN', 'KG', 'G', 'L', 'ML'],
    },
    { name: 'handledAt', type: 'date', required: true },
    { name: 'expiryDate', type: 'date', required: true },
    { name: 'lot', type: 'text', required: true },
    { name: 'responsibleName', type: 'text', required: true },
    {
      name: 'createdBy',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: { create: () => false, update: () => false },
    },
  ],
}
